// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VMIPS.h for the primary calling header

#include "VMIPS_MIPS.h"        // For This
#include "VMIPS__Syms.h"

//--------------------
// STATIC VARIABLES


//--------------------

VL_CTOR_IMP(VMIPS_MIPS) {
    // Reset internal values
    // Reset structure values
    { int __Vi0=0; for (; __Vi0<32; ++__Vi0) {
	    Reg_ID[__Vi0] = VL_RAND_RESET_I(32);
    }}
    R2_output = VL_RAND_RESET_I(32);
    data_address_2DM = VL_RAND_RESET_I(32);
    data_write_2DM = VL_RAND_RESET_I(32);
    VL_RAND_RESET_W(256,block_write_2DM);
    VL_RAND_RESET_W(256,block_write_2IM);
    MemRead = VL_RAND_RESET_I(1);
    MemWrite = VL_RAND_RESET_I(1);
    iBlkRead = 0;
    iBlkWrite = 0;
    dBlkRead = 0;
    dBlkWrite = 0;
    PC_init = VL_RAND_RESET_I(32);
    R2_input = VL_RAND_RESET_I(32);
    data_read_fDM = VL_RAND_RESET_I(32);
    VL_RAND_RESET_W(256,block_read_fDM);
    VL_RAND_RESET_W(256,block_read_fIM);
    Instr1_fIM = VL_RAND_RESET_I(32);
    Instr2_fIM = VL_RAND_RESET_I(32);
    Instr_read_fIC = VL_RAND_RESET_I(32);
    CLK = 0;
    RESET = 0;
    R2_output_ID = VL_RAND_RESET_I(32);
    Instr_fMEM = VL_RAND_RESET_I(32);
    Instr_address_2IM = VL_RAND_RESET_I(32);
    CIA_IFID = VL_RAND_RESET_I(32);
    PCA_IFID = VL_RAND_RESET_I(32);
    nextInstruction_address_IDIF = VL_RAND_RESET_I(32);
    no_fetch = VL_RAND_RESET_I(1);
    SYS = VL_RAND_RESET_I(1);
    single_fetch_IDIF = VL_RAND_RESET_I(1);
    __PVT__ALUSrc1_ID = VL_RAND_RESET_I(1);
    comment1 = VL_RAND_RESET_I(1);
    __PVT__OpA = VL_RAND_RESET_I(32);
    __PVT__OpB = VL_RAND_RESET_I(32);
    __PVT__tempInstruction_address = VL_RAND_RESET_I(32);
    __PVT__Instr1_IF = VL_RAND_RESET_I(32);
    __PVT__Instr1_ID = VL_RAND_RESET_I(32);
    __PVT__Instr1_EXE = VL_RAND_RESET_I(32);
    __PVT__aluResult1_MEM = VL_RAND_RESET_I(32);
    __PVT__aluResult1_WB = VL_RAND_RESET_I(32);
    __PVT__readDataB1_ID = VL_RAND_RESET_I(32);
    __PVT__readDataB1_EXE = VL_RAND_RESET_I(32);
    __PVT__MemData1 = VL_RAND_RESET_I(32);
    __PVT__writeData1_WB = VL_RAND_RESET_I(32);
    __PVT__writeData1_DST = VL_RAND_RESET_I(32);
    Instr1_IFID = VL_RAND_RESET_I(32);
    Instr2_IFID = VL_RAND_RESET_I(32);
    __PVT__ALU_control1_ID = VL_RAND_RESET_I(6);
    __PVT__ALU_control1_EXE = VL_RAND_RESET_I(6);
    __PVT__writeRegister1_ID = VL_RAND_RESET_I(5);
    __PVT__writeRegister1_MEM = VL_RAND_RESET_I(5);
    __PVT__writeRegister1_WB = VL_RAND_RESET_I(5);
    __PVT__writeRegister1_DST = VL_RAND_RESET_I(5);
    __PVT__readRegisterA1_ID = VL_RAND_RESET_I(5);
    __PVT__readRegisterB1_ID = VL_RAND_RESET_I(5);
    __PVT__readRegisterB1_EXE = VL_RAND_RESET_I(5);
    __PVT__Instr1_10_6_ID = VL_RAND_RESET_I(5);
    __PVT__jumpRegister = VL_RAND_RESET_I(5);
    __PVT__jumpR = VL_RAND_RESET_I(1);
    FREEZE = VL_RAND_RESET_I(1);
    __PVT__do_writeback1_EXE = VL_RAND_RESET_I(1);
    __PVT__do_writeback1_MEM = VL_RAND_RESET_I(1);
    __PVT__do_writeback1_WB = VL_RAND_RESET_I(1);
    __PVT__do_writeback1_DST = VL_RAND_RESET_I(1);
    __PVT__taken_branch1_ID = VL_RAND_RESET_I(1);
    __PVT__MemRead1_ID = VL_RAND_RESET_I(1);
    __PVT__MemRead1_EXE = VL_RAND_RESET_I(1);
    __PVT__MemWrite1_ID = VL_RAND_RESET_I(1);
    __PVT__MemWrite1_EXE = VL_RAND_RESET_I(1);
    __PVT__no_new_fetch = VL_RAND_RESET_I(1);
    __PVT__MemtoReg1_EXE = VL_RAND_RESET_I(1);
    __PVT__MemtoReg1_ID = VL_RAND_RESET_I(1);
    __PVT__MemtoReg1_MEM = VL_RAND_RESET_I(1);
    __PVT__IF1__DOT__PC = VL_RAND_RESET_I(32);
    __PVT__ID1__DOT__com_OpA1 = VL_RAND_RESET_I(32);
    __PVT__ID1__DOT__com_OpB1 = VL_RAND_RESET_I(32);
    __PVT__ID1__DOT__signExtended_output1 = VL_RAND_RESET_I(32);
    __PVT__ID1__DOT__readDataA1 = VL_RAND_RESET_I(32);
    __PVT__ID1__DOT__readDataB1 = VL_RAND_RESET_I(32);
    __PVT__ID1__DOT__ALU_control1 = VL_RAND_RESET_I(6);
    __PVT__ID1__DOT__opcode1 = VL_RAND_RESET_I(6);
    __PVT__ID1__DOT__funct1 = VL_RAND_RESET_I(6);
    __PVT__ID1__DOT__format1 = VL_RAND_RESET_I(5);
    __PVT__ID1__DOT__rt1 = VL_RAND_RESET_I(5);
    __PVT__ID1__DOT__writeRegister1 = VL_RAND_RESET_I(5);
    __PVT__ID1__DOT__syscal_stop = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__link1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__RegDst1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__jump1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__branch1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__MemRead1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__MemtoReg1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__MemWrite1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__ALUSrc1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__RegWrite1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__jumpRegister_Flag1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__sign_or_zero_Flag1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__syscal1 = VL_RAND_RESET_I(1);
    __PVT__ID1__DOT__syscalBubbleCounter = VL_RAND_RESET_I(2);
    __PVT__EXE1__DOT__aluResult1 = VL_RAND_RESET_I(32);
    __PVT__EXE1__DOT__OpA1 = VL_RAND_RESET_I(32);
    __PVT__EXE1__DOT__OpB1 = VL_RAND_RESET_I(32);
    __PVT__EXE1__DOT__OpRegisterB1 = VL_RAND_RESET_I(5);
    __PVT__EXE1__DOT__HI = VL_RAND_RESET_I(32);
    __PVT__EXE1__DOT__LO = VL_RAND_RESET_I(32);
    __PVT__EXE1__DOT__ALU1__DOT__temp = VL_RAND_RESET_Q(64);
    __PVT__EXE1__DOT__ALU1__DOT__i = VL_RAND_RESET_I(5);
    __PVT__MEM1__DOT__data_read_aligned = VL_RAND_RESET_I(32);
    __Vdly__ID1__DOT__syscalBubbleCounter = VL_RAND_RESET_I(2);
    __Vdly__tempInstruction_address = VL_RAND_RESET_I(32);
    __Vdly__writeRegister1_ID = VL_RAND_RESET_I(5);
    __Vdly__do_writeback1_EXE = VL_RAND_RESET_I(1);
    __Vdly__MemRead1_EXE = VL_RAND_RESET_I(1);
    __Vdly__aluResult1_MEM = VL_RAND_RESET_I(32);
    __Vdly__writeRegister1_MEM = VL_RAND_RESET_I(5);
    __Vdly__do_writeback1_MEM = VL_RAND_RESET_I(1);
    __Vdly__readRegisterB1_EXE = VL_RAND_RESET_I(5);
    __Vdlyvdim0__Reg_ID__v1 = 0;
    __Vdlyvval__Reg_ID__v1 = 0;
    __Vdlyvset__Reg_ID__v1 = 0;
    __Vdly__MemtoReg1_MEM = VL_RAND_RESET_I(1);
    __Vdly__writeRegister1_WB = VL_RAND_RESET_I(5);
    __Vdly__aluResult1_WB = VL_RAND_RESET_I(32);
    __Vdly__MemData1 = VL_RAND_RESET_I(32);
    __Vdly__do_writeback1_WB = VL_RAND_RESET_I(1);
}

void VMIPS_MIPS::__Vconfigure(VMIPS__Syms* vlSymsp, bool first) {
    if (0 && first) {}  // Prevent unused
    this->__VlSymsp = vlSymsp;
}

VMIPS_MIPS::~VMIPS_MIPS() {
}

//--------------------
// Internal Methods

void VMIPS_MIPS::_initial__TOP__v(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_initial__TOP__v\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // INITIAL at ID.v:163
    vlSymsp->TOP__v.FREEZE = 0;
}

void VMIPS_MIPS::_sequent__TOP__v__1(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_sequent__TOP__v__1\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v.__Vdly__ID1__DOT__syscalBubbleCounter 
	= vlSymsp->TOP__v.__PVT__ID1__DOT__syscalBubbleCounter;
    vlSymsp->TOP__v.__Vdly__writeRegister1_ID = vlSymsp->TOP__v.__PVT__writeRegister1_ID;
    vlSymsp->TOP__v.__Vdly__do_writeback1_EXE = vlSymsp->TOP__v.__PVT__do_writeback1_EXE;
    vlSymsp->TOP__v.__Vdly__tempInstruction_address 
	= vlSymsp->TOP__v.__PVT__tempInstruction_address;
    vlSymsp->TOP__v.__Vdly__MemRead1_EXE = vlSymsp->TOP__v.__PVT__MemRead1_EXE;
    vlSymsp->TOP__v.__Vdly__readRegisterB1_EXE = vlSymsp->TOP__v.__PVT__readRegisterB1_EXE;
    vlSymsp->TOP__v.__Vdly__aluResult1_MEM = vlSymsp->TOP__v.__PVT__aluResult1_MEM;
    vlSymsp->TOP__v.__Vdly__writeRegister1_MEM = vlSymsp->TOP__v.__PVT__writeRegister1_MEM;
    vlSymsp->TOP__v.__Vdly__do_writeback1_MEM = vlSymsp->TOP__v.__PVT__do_writeback1_MEM;
    // ALWAYS at ID.v:297
    if (vlTOPp->RESET) {
	if (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1) 
	     & (~ (IData)(vlSymsp->TOP__v.__PVT__no_new_fetch)))) {
	    vlSymsp->TOP__v.__Vdly__ID1__DOT__syscalBubbleCounter = 0;
	} else {
	    if ((3 != (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscalBubbleCounter))) {
		vlSymsp->TOP__v.__Vdly__ID1__DOT__syscalBubbleCounter 
		    = (3 & ((IData)(1) + (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscalBubbleCounter)));
	    }
	}
    } else {
	vlSymsp->TOP__v.R2_output = 0;
	vlSymsp->TOP__v.__Vdly__tempInstruction_address = 0;
	vlSymsp->TOP__v.__Vdly__ID1__DOT__syscalBubbleCounter = 3;
    }
    vlSymsp->TOP__v.__PVT__ID1__DOT__syscalBubbleCounter 
	= vlSymsp->TOP__v.__Vdly__ID1__DOT__syscalBubbleCounter;
}

void VMIPS_MIPS::_sequent__TOP__v__2(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_sequent__TOP__v__2\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v.__Vdlyvset__Reg_ID__v1 = 0;
    // ALWAYS at ID.v:313
    if (vlSymsp->TOP__v.__PVT__do_writeback1_WB) {
	vlSymsp->TOP__v.__Vdlyvval__Reg_ID__v1 = vlSymsp->TOP__v.__PVT__writeData1_WB;
	vlSymsp->TOP__v.__Vdlyvset__Reg_ID__v1 = 1;
	vlSymsp->TOP__v.__Vdlyvdim0__Reg_ID__v1 = vlSymsp->TOP__v.__PVT__writeRegister1_WB;
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("Reg%x is being assigned to %x\n",
		      5,vlSymsp->TOP__v.__PVT__writeRegister1_WB,
		      32,vlSymsp->TOP__v.__PVT__writeData1_WB);
	}
    }
    // ALWAYSPOST at ID.v:314
    vlSymsp->TOP__v.Reg_ID[0] = 0;
    if (vlSymsp->TOP__v.__Vdlyvset__Reg_ID__v1) {
	vlSymsp->TOP__v.Reg_ID[(IData)(vlSymsp->TOP__v.__Vdlyvdim0__Reg_ID__v1)] 
	    = vlSymsp->TOP__v.__Vdlyvval__Reg_ID__v1;
    }
}

void VMIPS_MIPS::_sequent__TOP__v__3(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_sequent__TOP__v__3\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v.__Vdly__writeRegister1_WB = vlSymsp->TOP__v.__PVT__writeRegister1_WB;
    vlSymsp->TOP__v.__Vdly__do_writeback1_WB = vlSymsp->TOP__v.__PVT__do_writeback1_WB;
    vlSymsp->TOP__v.__Vdly__MemData1 = vlSymsp->TOP__v.__PVT__MemData1;
    vlSymsp->TOP__v.__Vdly__aluResult1_WB = vlSymsp->TOP__v.__PVT__aluResult1_WB;
    vlSymsp->TOP__v.__Vdly__MemtoReg1_MEM = vlSymsp->TOP__v.__PVT__MemtoReg1_MEM;
    // ALWAYS at MEM.v:154
    if (vlTOPp->RESET) {
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("MemtoReg1_WB is %x\n",1,vlSymsp->TOP__v.__PVT__MemtoReg1_MEM);
	}
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("writeRegister_MEM is %x\n",5,
		      vlSymsp->TOP__v.__PVT__writeRegister1_WB);
	}
	vlSymsp->TOP__v.__Vdly__MemtoReg1_MEM = vlSymsp->TOP__v.__PVT__MemtoReg1_EXE;
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("aluResult1_WB is %x\n",32,vlSymsp->TOP__v.__PVT__aluResult1_WB);
	}
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("data_read_WB is %x\n",32,vlSymsp->TOP__v.__PVT__MemData1);
	}
	vlSymsp->TOP__v.__Vdly__writeRegister1_WB = vlSymsp->TOP__v.__PVT__writeRegister1_MEM;
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("do_writeback_WB is %x\n",1,vlSymsp->TOP__v.__PVT__do_writeback1_WB);
	}
	vlSymsp->TOP__v.__Vdly__aluResult1_WB = vlSymsp->TOP__v.__PVT__aluResult1_MEM;
	vlSymsp->TOP__v.__Vdly__MemData1 = vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned;
	vlSymsp->TOP__v.__Vdly__do_writeback1_WB = 
	    ((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
	     | (IData)(vlSymsp->TOP__v.__PVT__MemtoReg1_EXE));
    } else {
	vlSymsp->TOP__v.__Vdly__MemtoReg1_MEM = 0;
	vlSymsp->TOP__v.__Vdly__writeRegister1_WB = 0;
	vlSymsp->TOP__v.__Vdly__aluResult1_WB = 0;
	vlSymsp->TOP__v.__Vdly__MemData1 = 0;
	vlSymsp->TOP__v.__Vdly__do_writeback1_WB = 0;
    }
    vlSymsp->TOP__v.__PVT__MemData1 = vlSymsp->TOP__v.__Vdly__MemData1;
    vlSymsp->TOP__v.__PVT__aluResult1_WB = vlSymsp->TOP__v.__Vdly__aluResult1_WB;
    vlSymsp->TOP__v.__PVT__MemtoReg1_MEM = vlSymsp->TOP__v.__Vdly__MemtoReg1_MEM;
}

void VMIPS_MIPS::_sequent__TOP__v__4(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_sequent__TOP__v__4\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // ALWAYS at EXE.v:120
    if (vlTOPp->RESET) {
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("OpB1 is %x\n",32,vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1);
	}
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("OpA1 is %x\n",32,vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1);
	}
	vlSymsp->TOP__v.__PVT__MemtoReg1_EXE = vlSymsp->TOP__v.__PVT__MemtoReg1_ID;
	vlSymsp->TOP__v.__PVT__MemWrite1_EXE = vlSymsp->TOP__v.__PVT__MemWrite1_ID;
	vlSymsp->TOP__v.__PVT__ALU_control1_EXE = vlSymsp->TOP__v.__PVT__ALU_control1_ID;
	vlSymsp->TOP__v.__PVT__Instr1_EXE = vlSymsp->TOP__v.__PVT__Instr1_ID;
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("MeadRead_EXE is %x\n",1,vlSymsp->TOP__v.__PVT__MemRead1_EXE);
	}
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("aluResult1_MEM is %x\n",32,vlSymsp->TOP__v.__PVT__aluResult1_MEM);
	}
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("writeRegister_EXE is %x\n",5,
		      vlSymsp->TOP__v.__PVT__writeRegister1_MEM);
	}
	vlSymsp->TOP__v.__Vdly__MemRead1_EXE = vlSymsp->TOP__v.__PVT__MemRead1_ID;
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("do_writeback_EXE is %x\n",1,
		      vlSymsp->TOP__v.__PVT__do_writeback1_MEM);
	}
	vlSymsp->TOP__v.__PVT__readDataB1_EXE = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
						  & ((IData)(vlSymsp->TOP__v.__PVT__readRegisterB1_ID) 
						     == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM)))
						  ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
						  : 
						 (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__readRegisterB1_ID) 
						      == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB)))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : 
						  (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_DST) 
						    & ((IData)(vlSymsp->TOP__v.__PVT__readRegisterB1_ID) 
						       == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_DST)))
						    ? vlSymsp->TOP__v.__PVT__writeData1_DST
						    : vlSymsp->TOP__v.__PVT__readDataB1_ID)));
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("readRegisterB1 is %x\n",5,vlSymsp->TOP__v.__PVT__readRegisterB1_EXE);
	}
	vlSymsp->TOP__v.__Vdly__aluResult1_MEM = vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1;
	vlSymsp->TOP__v.__Vdly__writeRegister1_MEM 
	    = vlSymsp->TOP__v.__PVT__writeRegister1_ID;
	vlSymsp->TOP__v.__Vdly__do_writeback1_MEM = vlSymsp->TOP__v.__PVT__do_writeback1_EXE;
	vlSymsp->TOP__v.__Vdly__readRegisterB1_EXE 
	    = vlSymsp->TOP__v.__PVT__readRegisterB1_ID;
    } else {
	vlSymsp->TOP__v.__PVT__MemtoReg1_EXE = 0;
	vlSymsp->TOP__v.__Vdly__MemRead1_EXE = 0;
	vlSymsp->TOP__v.__PVT__MemWrite1_EXE = 0;
	vlSymsp->TOP__v.__Vdly__aluResult1_MEM = 0;
	vlSymsp->TOP__v.__Vdly__writeRegister1_MEM = 0;
	vlSymsp->TOP__v.__Vdly__do_writeback1_MEM = 0;
	vlSymsp->TOP__v.__PVT__ALU_control1_EXE = 0;
	vlSymsp->TOP__v.__PVT__readDataB1_EXE = 0;
	vlSymsp->TOP__v.__PVT__Instr1_EXE = 0;
    }
    vlSymsp->TOP__v.__PVT__MemRead1_EXE = vlSymsp->TOP__v.__Vdly__MemRead1_EXE;
    vlSymsp->TOP__v.__PVT__readRegisterB1_EXE = vlSymsp->TOP__v.__Vdly__readRegisterB1_EXE;
    vlSymsp->TOP__v.__PVT__aluResult1_MEM = vlSymsp->TOP__v.__Vdly__aluResult1_MEM;
    vlSymsp->TOP__v.__PVT__writeRegister1_MEM = vlSymsp->TOP__v.__Vdly__writeRegister1_MEM;
    vlSymsp->TOP__v.__PVT__do_writeback1_MEM = vlSymsp->TOP__v.__Vdly__do_writeback1_MEM;
    vlSymsp->TOP__v.Instr_fMEM = vlSymsp->TOP__v.__PVT__Instr1_EXE;
    // ALWAYS at WB.v:46
    if (vlTOPp->RESET) {
	vlSymsp->TOP__v.__PVT__writeData1_DST = vlSymsp->TOP__v.__PVT__writeData1_WB;
	vlSymsp->TOP__v.__PVT__writeRegister1_DST = vlSymsp->TOP__v.__PVT__writeRegister1_WB;
	vlSymsp->TOP__v.__PVT__do_writeback1_DST = vlSymsp->TOP__v.__PVT__do_writeback1_WB;
    } else {
	vlSymsp->TOP__v.__PVT__writeData1_DST = 0;
	vlSymsp->TOP__v.__PVT__writeRegister1_DST = 0;
	vlSymsp->TOP__v.__PVT__do_writeback1_DST = 0;
    }
    // ALWAYS at ID.v:324
    if ((1 & ((~ (IData)(vlTOPp->RESET)) | (IData)(vlSymsp->TOP__v.__PVT__no_new_fetch)))) {
	vlSymsp->TOP__v.__PVT__OpA = 0;
	vlSymsp->TOP__v.__PVT__OpB = 0;
	vlSymsp->TOP__v.__Vdly__writeRegister1_ID = 0;
	vlSymsp->TOP__v.__PVT__taken_branch1_ID = 0;
	vlSymsp->TOP__v.__PVT__MemRead1_ID = 0;
	vlSymsp->TOP__v.__PVT__MemtoReg1_ID = 0;
	vlSymsp->TOP__v.__PVT__MemWrite1_ID = 0;
	vlSymsp->TOP__v.__PVT__ALU_control1_ID = 0;
	vlSymsp->TOP__v.__PVT__readRegisterA1_ID = 0;
	vlSymsp->TOP__v.__PVT__readRegisterB1_ID = 0;
	vlSymsp->TOP__v.__Vdly__do_writeback1_EXE = 0;
	vlSymsp->TOP__v.__PVT__Instr1_10_6_ID = 0;
	vlSymsp->TOP__v.__PVT__readDataB1_ID = 0;
	vlSymsp->TOP__v.__PVT__Instr1_ID = 0;
	vlSymsp->TOP__v.__PVT__ALUSrc1_ID = 0;
	vlSymsp->TOP__v.__PVT__jumpR = 0;
	vlSymsp->TOP__v.__PVT__jumpRegister = 0;
    } else {
	vlSymsp->TOP__v.__PVT__OpA = ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__link1)
				       ? vlSymsp->TOP__v.PCA_IFID
				       : ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1)
					   ? vlTOPp->R2_input
					   : vlSymsp->TOP__v.__PVT__ID1__DOT__readDataA1));
	vlSymsp->TOP__v.__PVT__OpB = ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__link1)
				       ? 4 : ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1)
					       ? 0 : 
					      ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1)
					        ? vlSymsp->TOP__v.__PVT__ID1__DOT__signExtended_output1
					        : vlSymsp->TOP__v.__PVT__ID1__DOT__readDataB1)));
	vlSymsp->TOP__v.__PVT__taken_branch1_ID = (
						   ((((~ 
						       (vlSymsp->TOP__v.__PVT__Instr1_IF 
							>> 0x1f)) 
						      & ((~ 
							  (vlSymsp->TOP__v.__PVT__Instr1_IF 
							   >> 0x1e)) 
							 & ((~ 
							     (vlSymsp->TOP__v.__PVT__Instr1_IF 
							      >> 0x1d)) 
							    & ((0x10000000 
								& vlSymsp->TOP__v.__PVT__Instr1_IF)
							        ? 
							       ((0x8000000 
								 & vlSymsp->TOP__v.__PVT__Instr1_IF)
								 ? 
								((0x4000000 
								  & vlSymsp->TOP__v.__PVT__Instr1_IF)
								  ? 
								 ((0 
								   == 
								   (1 
								    & (vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1 
								       >> 0x1f))) 
								  & (0 
								     != vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1))
								  : 
								 ((1 
								   == 
								   (1 
								    & (vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1 
								       >> 0x1f))) 
								  | (0 
								     == vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1)))
								 : 
								((0x4000000 
								  & vlSymsp->TOP__v.__PVT__Instr1_IF)
								  ? 
								 (vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1 
								  != vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpB1)
								  : 
								 (vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1 
								  == vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpB1)))
							        : 
							       ((~ 
								 (vlSymsp->TOP__v.__PVT__Instr1_IF 
								  >> 0x1b)) 
								& ((vlSymsp->TOP__v.__PVT__Instr1_IF 
								    >> 0x1a) 
								   & ((~ 
								       (vlSymsp->TOP__v.__PVT__Instr1_IF 
									>> 0x13)) 
								      & ((~ 
									  (vlSymsp->TOP__v.__PVT__Instr1_IF 
									   >> 0x12)) 
									 & ((~ 
									     (vlSymsp->TOP__v.__PVT__Instr1_IF 
									      >> 0x11)) 
									    & ((0x10000 
										& vlSymsp->TOP__v.__PVT__Instr1_IF)
									        ? 
									       (0 
										== 
										(1 
										& (vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1 
										>> 0x1f)))
									        : 
									       (1 
										== 
										(1 
										& (vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1 
										>> 0x1f))))))))))))) 
						     | (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jump1)) 
						    & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__branch1)) 
						   | (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jump1));
	vlSymsp->TOP__v.__PVT__MemRead1_ID = vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1;
	vlSymsp->TOP__v.__PVT__MemtoReg1_ID = vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1;
	vlSymsp->TOP__v.__PVT__MemWrite1_ID = vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1;
	vlSymsp->TOP__v.__PVT__ALU_control1_ID = vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1;
	vlSymsp->TOP__v.__PVT__readRegisterA1_ID = 
	    (0x1f & (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__link1) 
		      | (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1))
		      ? 0 : (vlSymsp->TOP__v.__PVT__Instr1_IF 
			     >> 0x15)));
	vlSymsp->TOP__v.__PVT__jumpRegister = (0x1f 
					       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
						  >> 0x15));
	vlSymsp->TOP__v.__PVT__readRegisterB1_ID = 
	    (0x1f & (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__link1) 
		      | (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1))
		      ? 0 : (vlSymsp->TOP__v.__PVT__Instr1_IF 
			     >> 0x10)));
	vlSymsp->TOP__v.__PVT__Instr1_10_6_ID = (0x1f 
						 & (vlSymsp->TOP__v.__PVT__Instr1_IF 
						    >> 6));
	vlSymsp->TOP__v.__PVT__readDataB1_ID = vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpB1;
	vlSymsp->TOP__v.__PVT__Instr1_ID = vlSymsp->TOP__v.__PVT__Instr1_IF;
	vlSymsp->TOP__v.__PVT__ALUSrc1_ID = vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1;
	vlSymsp->TOP__v.__PVT__jumpR = ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jump1) 
					& (~ (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1)));
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("writeRegister_ID is %x\n",5,
		      vlSymsp->TOP__v.__PVT__writeRegister1_ID);
	}
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("do_writeback_ID is %x\n",1,vlSymsp->TOP__v.__PVT__do_writeback1_EXE);
	}
	vlSymsp->TOP__v.__Vdly__tempInstruction_address 
	    = ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jump1)
	        ? ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1)
		    ? (vlSymsp->TOP__v.PCA_IFID + (
						   (0xf0000000 
						    & (VL_NEGATE_I((IData)(
									   (1 
									    & (vlSymsp->TOP__v.__PVT__Instr1_IF 
									       >> 0x19)))) 
						       << 0x1c)) 
						   | (0xffffffc 
						      & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							 << 2))))
		    : vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1)
	        : (vlSymsp->TOP__v.PCA_IFID + (vlSymsp->TOP__v.__PVT__ID1__DOT__signExtended_output1 
					       << 2)));
	vlSymsp->TOP__v.__Vdly__writeRegister1_ID = vlSymsp->TOP__v.__PVT__ID1__DOT__writeRegister1;
	if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
	    VL_WRITEF("nextInstruction_address_ID is %x\n",
		      32,vlSymsp->TOP__v.__PVT__tempInstruction_address);
	}
	vlSymsp->TOP__v.__Vdly__do_writeback1_EXE = 
	    ((((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1) 
	       & (0 != (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__writeRegister1))) 
	      & (0x34 != (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1))) 
	     & (~ (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1)));
    }
    vlSymsp->TOP__v.__PVT__writeRegister1_ID = vlSymsp->TOP__v.__Vdly__writeRegister1_ID;
    vlSymsp->TOP__v.__PVT__tempInstruction_address 
	= vlSymsp->TOP__v.__Vdly__tempInstruction_address;
    vlSymsp->TOP__v.__PVT__do_writeback1_EXE = vlSymsp->TOP__v.__Vdly__do_writeback1_EXE;
    vlSymsp->TOP__v.__PVT__EXE1__DOT__OpRegisterB1 
	= ((IData)(vlSymsp->TOP__v.__PVT__ALUSrc1_ID)
	    ? 0 : (IData)(vlSymsp->TOP__v.__PVT__readRegisterB1_ID));
    // ALWAYS at IF.v:44
    if (vlTOPp->RESET) {
	if ((1 & ((~ (IData)(vlSymsp->TOP__v.__PVT__no_new_fetch)) 
		  & (~ (IData)(vlSymsp->TOP__v.FREEZE))))) {
	    vlSymsp->TOP__v.__PVT__Instr1_IF = vlTOPp->Instr1_fIM;
	    vlSymsp->TOP__v.__PVT__IF1__DOT__PC = ((IData)(4) 
						   + vlSymsp->TOP__v.Instr_address_2IM);
	} else {
	    if (vlSymsp->TOP__v.FREEZE) {
		vlSymsp->TOP__v.__PVT__Instr1_IF = 0;
	    }
	}
    } else {
	vlSymsp->TOP__v.__PVT__Instr1_IF = 0;
	vlSymsp->TOP__v.__PVT__IF1__DOT__PC = vlTOPp->PC_init;
    }
    vlSymsp->TOP__v.PCA_IFID = vlSymsp->TOP__v.__PVT__IF1__DOT__PC;
    vlSymsp->TOP__v.Instr1_IFID = vlSymsp->TOP__v.__PVT__Instr1_IF;
    vlSymsp->TOP__v.__PVT__ID1__DOT__readDataA1 = vlSymsp->TOP__v.Reg_ID
	[(0x1f & (vlSymsp->TOP__v.__PVT__Instr1_IF 
		  >> 0x15))];
    vlSymsp->TOP__v.__PVT__ID1__DOT__readDataB1 = vlSymsp->TOP__v.Reg_ID
	[(0x1f & (vlSymsp->TOP__v.__PVT__Instr1_IF 
		  >> 0x10))];
    // ALWAYS at ID.v:179
    vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1 = (0x3f 
						& (vlSymsp->TOP__v.__PVT__Instr1_IF 
						   >> 0x1a));
    vlSymsp->TOP__v.__PVT__ID1__DOT__format1 = (0x1f 
						& (vlSymsp->TOP__v.__PVT__Instr1_IF 
						   >> 0x15));
    vlSymsp->TOP__v.__PVT__ID1__DOT__rt1 = (0x1f & 
					    (vlSymsp->TOP__v.__PVT__Instr1_IF 
					     >> 0x10));
    vlSymsp->TOP__v.__PVT__ID1__DOT__funct1 = (0x3f 
					       & vlSymsp->TOP__v.__PVT__Instr1_IF);
    if ((0x20 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
	if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		if (VL_UNLIKELY((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
		    VL_WRITEF("Not an Instruction!\n");
		} else {
		    if (VL_UNLIKELY((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			VL_WRITEF("Not an Instruction!\n");
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]swc1\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x39;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]swc0\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x31;
			}
		    }
		}
	    } else {
		if (VL_UNLIKELY((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
		    VL_WRITEF("Not an Instruction!\n");
		} else {
		    if (VL_UNLIKELY((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			VL_WRITEF("Not an Instruction!\n");
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lwc1\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x35;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lwc0\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3d;
			}
		    }
		}
	    }
	} else {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if (VL_LIKELY((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			if (VL_UNLIKELY((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			    VL_WRITEF("Not an Instruction!\n");
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]swr\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x33;
			}
		    } else {
			VL_WRITEF("Not an Instruction!\n");
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]sw\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x31;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]swl\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x32;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]sh\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x30;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]sb\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2f;
			}
		    }
		}
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if (VL_UNLIKELY((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			    VL_WRITEF("Not an Instruction!\n");
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lwr\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2e;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lhu\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2c;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lbu\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2a;
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lw\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3d;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lwl\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2d;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lh\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2b;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lb\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x21;
			}
		    }
		}
	    }
	}
    } else {
	if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
	    if (VL_UNLIKELY((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
		VL_WRITEF("Not an Instruction!\n");
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if (VL_UNLIKELY((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			    VL_WRITEF("Not an Instruction!\n");
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]blezl\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3b;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]bnel\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3c;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]beql\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3a;
			}
		    }
		} else {
		    if (VL_UNLIKELY((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			VL_WRITEF("Not an Instruction!\n");
		    } else {
			if (VL_LIKELY((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			    if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
				if (VL_UNLIKELY((8 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
				    VL_WRITEF("Not an Instruction!\n");
				} else {
				    if (VL_UNLIKELY(
						    (4 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
					VL_WRITEF("Not an Instruction!\n");
				    } else {
					if (VL_UNLIKELY(
							(2 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((1 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]fp cvt.s\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 8;
					    } else {
						if (
						    (3 
						     == 
						     (0xf 
						      & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							 >> 4)))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]fp c.cond\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1f;
						} else {
						    if (VL_UNLIKELY(
								    (0x20 
								     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
							VL_WRITEF("Not an Instruction!\n");
						    } else {
							if (VL_UNLIKELY(
									(0x10 
									 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
							    VL_WRITEF("Not an Instruction!\n");
							} else {
							    if (VL_UNLIKELY(
									    (8 
									     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
								VL_WRITEF("Not an Instruction!\n");
							    } else {
								if (
								    (4 
								     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
								    if (
									(2 
									 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									if (
									    (1 
									     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp neg\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x10;
									} else {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp mov\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 4;
									}
								    } else {
									if (VL_LIKELY(
										(1 
										& (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp abs\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x37;
									} else {
									    VL_WRITEF("Not an Instruction!\n");
									}
								    }
								} else {
								    if (
									(2 
									 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									if (
									    (1 
									     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp div\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 5;
									} else {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp mul\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xd;
									}
								    } else {
									if (
									    (1 
									     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp sub\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0;
									} else {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp add\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1b;
									}
								    }
								}
							    }
							}
						    }
						}
					    }
					}
				    }
				}
			    } else {
				if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
				    if (VL_UNLIKELY(
						    (4 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
					VL_WRITEF("Not an Instruction!\n");
				    } else {
					if (VL_UNLIKELY(
							(2 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (
						    (0x10000 
						     & vlSymsp->TOP__v.__PVT__Instr1_IF)) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]bc1t\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1d;
						} else {
						    if (
							(1 
							 & (~ 
							    (vlSymsp->TOP__v.__PVT__Instr1_IF 
							     >> 0x10)))) {
							if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							    VL_WRITEF("[1]bc1f\n\n");
							}
							vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
							vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
							vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xf;
						    }
						}
					    }
					}
				    }
				} else {
				    if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
					if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]ctc1\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x34;
					    }
					} else {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]mtc1\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x38;
					    }
					}
				    } else {
					if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]cfc1\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1a;
					    }
					} else {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]mfc1\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1c;
					    }
					}
				    }
				}
			    }
			} else {
			    VL_WRITEF("Not an Instruction!\n");
			}
		    }
		}
	    }
	} else {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lui\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 8;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]xori\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x20;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]ori\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x10;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]andi\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 4;
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]sltiu\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x15;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]slti\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x15;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]addiu\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 2;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]addi\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
			}
		    }
		}
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]bgtz\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x25;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]blez\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x26;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]bne\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x29;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]beq\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x22;
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]jal\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]jump\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xe;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1))) {
				if (VL_UNLIKELY((8 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
				    VL_WRITEF("Not an Instruction!\n");
				} else {
				    if (VL_UNLIKELY(
						    (4 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
					VL_WRITEF("Not an Instruction!\n");
				    } else {
					if (VL_UNLIKELY(
							(2 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((1 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1))) {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]bgezal\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]bltzal\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
					    }
					}
				    }
				}
			    } else {
				if (VL_UNLIKELY((8 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
				    VL_WRITEF("Not an Instruction!\n");
				} else {
				    if (VL_UNLIKELY(
						    (4 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
					VL_WRITEF("Not an Instruction!\n");
				    } else {
					if (VL_UNLIKELY(
							(2 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((1 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1))) {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]bgez\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x23;
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]bltz\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x27;
					    }
					}
				    }
				}
			    }
			} else {
			    if ((0x20 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
				if (VL_UNLIKELY((0x10 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
				    VL_WRITEF("Not an Instruction!\n");
				} else {
				    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					if (VL_UNLIKELY(
							(4 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if (VL_LIKELY(
							  (2 
							   & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sltu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3f;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]slt\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x15;
						}
					    } else {
						VL_WRITEF("Not an Instruction!\n");
					    }
					}
				    } else {
					if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]nor\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xf;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]xor\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1f;
						}
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]or\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x10;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]and\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 4;
						}
					    }
					} else {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]subu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1e;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sub\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1d;
						}
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]addu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x37;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]add\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0;
						}
					    }
					}
				    }
				}
			    } else {
				if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
				    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					if (VL_UNLIKELY(
							(4 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]divu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 6;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]div\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 5;
						}
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]multu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xd;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mult\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xd;
						}
					    }
					}
				    } else {
					if (VL_UNLIKELY(
							(4 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mtlo\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xc;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mflo\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xa;
						}
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mthi\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xb;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mfhi\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 9;
						}
					    }
					}
				    }
				} else {
				    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					    if (VL_UNLIKELY(
							    (2 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]break\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x13;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]syscal1\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
						}
					    }
					} else {
					    if (VL_UNLIKELY(
							    (2 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]jalr\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]jr\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3e;
						}
					    }
					}
				    } else {
					if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]srav\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1a;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]srlv\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1c;
						}
					    } else {
						if (VL_UNLIKELY(
								(1 
								 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						    VL_WRITEF("Not an Instruction!\n");
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sllv\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x14;
						}
					    }
					} else {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sra\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x19;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]srl\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1b;
						}
					    } else {
						if (VL_UNLIKELY(
								(1 
								 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						    VL_WRITEF("Not an Instruction!\n");
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sll,nop\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x13;
						}
					    }
					}
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
}

void VMIPS_MIPS::_settle__TOP__v__5(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_settle__TOP__v__5\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v.Instr_fMEM = vlSymsp->TOP__v.__PVT__Instr1_EXE;
    vlSymsp->TOP__v.__PVT__writeData1_WB = ((IData)(vlSymsp->TOP__v.__PVT__MemtoReg1_MEM)
					     ? vlSymsp->TOP__v.__PVT__MemData1
					     : vlSymsp->TOP__v.__PVT__aluResult1_WB);
    vlSymsp->TOP__v.__PVT__EXE1__DOT__OpRegisterB1 
	= ((IData)(vlSymsp->TOP__v.__PVT__ALUSrc1_ID)
	    ? 0 : (IData)(vlSymsp->TOP__v.__PVT__readRegisterB1_ID));
    vlSymsp->TOP__v.PCA_IFID = vlSymsp->TOP__v.__PVT__IF1__DOT__PC;
    vlSymsp->TOP__v.Instr1_IFID = vlSymsp->TOP__v.__PVT__Instr1_IF;
    vlSymsp->TOP__v.__PVT__ID1__DOT__readDataB1 = vlSymsp->TOP__v.Reg_ID
	[(0x1f & (vlSymsp->TOP__v.__PVT__Instr1_IF 
		  >> 0x10))];
    vlSymsp->TOP__v.__PVT__ID1__DOT__readDataA1 = vlSymsp->TOP__v.Reg_ID
	[(0x1f & (vlSymsp->TOP__v.__PVT__Instr1_IF 
		  >> 0x15))];
    // ALWAYS at ID.v:179
    vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1 = (0x3f 
						& (vlSymsp->TOP__v.__PVT__Instr1_IF 
						   >> 0x1a));
    vlSymsp->TOP__v.__PVT__ID1__DOT__format1 = (0x1f 
						& (vlSymsp->TOP__v.__PVT__Instr1_IF 
						   >> 0x15));
    vlSymsp->TOP__v.__PVT__ID1__DOT__rt1 = (0x1f & 
					    (vlSymsp->TOP__v.__PVT__Instr1_IF 
					     >> 0x10));
    vlSymsp->TOP__v.__PVT__ID1__DOT__funct1 = (0x3f 
					       & vlSymsp->TOP__v.__PVT__Instr1_IF);
    if ((0x20 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
	if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		if (VL_UNLIKELY((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
		    VL_WRITEF("Not an Instruction!\n");
		} else {
		    if (VL_UNLIKELY((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			VL_WRITEF("Not an Instruction!\n");
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]swc1\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x39;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]swc0\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x31;
			}
		    }
		}
	    } else {
		if (VL_UNLIKELY((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
		    VL_WRITEF("Not an Instruction!\n");
		} else {
		    if (VL_UNLIKELY((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			VL_WRITEF("Not an Instruction!\n");
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lwc1\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x35;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lwc0\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3d;
			}
		    }
		}
	    }
	} else {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if (VL_LIKELY((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			if (VL_UNLIKELY((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			    VL_WRITEF("Not an Instruction!\n");
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]swr\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x33;
			}
		    } else {
			VL_WRITEF("Not an Instruction!\n");
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]sw\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x31;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]swl\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x32;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]sh\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x30;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]sb\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2f;
			}
		    }
		}
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if (VL_UNLIKELY((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			    VL_WRITEF("Not an Instruction!\n");
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lwr\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2e;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lhu\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2c;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lbu\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2a;
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lw\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3d;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lwl\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2d;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lh\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x2b;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lb\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x21;
			}
		    }
		}
	    }
	}
    } else {
	if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
	    if (VL_UNLIKELY((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
		VL_WRITEF("Not an Instruction!\n");
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if (VL_UNLIKELY((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			    VL_WRITEF("Not an Instruction!\n");
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]blezl\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3b;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]bnel\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3c;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]beql\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3a;
			}
		    }
		} else {
		    if (VL_UNLIKELY((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			VL_WRITEF("Not an Instruction!\n");
		    } else {
			if (VL_LIKELY((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1)))) {
			    if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
				if (VL_UNLIKELY((8 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
				    VL_WRITEF("Not an Instruction!\n");
				} else {
				    if (VL_UNLIKELY(
						    (4 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
					VL_WRITEF("Not an Instruction!\n");
				    } else {
					if (VL_UNLIKELY(
							(2 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((1 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]fp cvt.s\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 8;
					    } else {
						if (
						    (3 
						     == 
						     (0xf 
						      & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							 >> 4)))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]fp c.cond\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1f;
						} else {
						    if (VL_UNLIKELY(
								    (0x20 
								     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
							VL_WRITEF("Not an Instruction!\n");
						    } else {
							if (VL_UNLIKELY(
									(0x10 
									 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
							    VL_WRITEF("Not an Instruction!\n");
							} else {
							    if (VL_UNLIKELY(
									    (8 
									     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
								VL_WRITEF("Not an Instruction!\n");
							    } else {
								if (
								    (4 
								     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
								    if (
									(2 
									 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									if (
									    (1 
									     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp neg\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x10;
									} else {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp mov\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 4;
									}
								    } else {
									if (VL_LIKELY(
										(1 
										& (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp abs\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x37;
									} else {
									    VL_WRITEF("Not an Instruction!\n");
									}
								    }
								} else {
								    if (
									(2 
									 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									if (
									    (1 
									     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp div\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 5;
									} else {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp mul\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xd;
									}
								    } else {
									if (
									    (1 
									     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp sub\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0;
									} else {
									    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
										VL_WRITEF("[1]fp add\n\n");
									    }
									    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
									    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1b;
									}
								    }
								}
							    }
							}
						    }
						}
					    }
					}
				    }
				}
			    } else {
				if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
				    if (VL_UNLIKELY(
						    (4 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
					VL_WRITEF("Not an Instruction!\n");
				    } else {
					if (VL_UNLIKELY(
							(2 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (
						    (0x10000 
						     & vlSymsp->TOP__v.__PVT__Instr1_IF)) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]bc1t\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1d;
						} else {
						    if (
							(1 
							 & (~ 
							    (vlSymsp->TOP__v.__PVT__Instr1_IF 
							     >> 0x10)))) {
							if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							    VL_WRITEF("[1]bc1f\n\n");
							}
							vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
							vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
							vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
							vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xf;
						    }
						}
					    }
					}
				    }
				} else {
				    if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
					if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]ctc1\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x34;
					    }
					} else {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]mtc1\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x38;
					    }
					}
				    } else {
					if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1))) {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]cfc1\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1a;
					    }
					} else {
					    if (VL_UNLIKELY(
							    (1 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__format1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]mfc1\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1c;
					    }
					}
				    }
				}
			    }
			} else {
			    VL_WRITEF("Not an Instruction!\n");
			}
		    }
		}
	    }
	} else {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]lui\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 8;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]xori\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x20;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]ori\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x10;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]andi\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 4;
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]sltiu\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x15;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]slti\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x15;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]addiu\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 2;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]addi\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
			}
		    }
		}
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]bgtz\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x25;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]blez\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x26;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]bne\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x29;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]beq\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x22;
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]jal\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
			} else {
			    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
				VL_WRITEF("[1]jump\n\n");
			    }
			    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
			    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xe;
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__opcode1))) {
			    if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1))) {
				if (VL_UNLIKELY((8 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
				    VL_WRITEF("Not an Instruction!\n");
				} else {
				    if (VL_UNLIKELY(
						    (4 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
					VL_WRITEF("Not an Instruction!\n");
				    } else {
					if (VL_UNLIKELY(
							(2 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((1 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1))) {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]bgezal\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]bltzal\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
					    }
					}
				    }
				}
			    } else {
				if (VL_UNLIKELY((8 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
				    VL_WRITEF("Not an Instruction!\n");
				} else {
				    if (VL_UNLIKELY(
						    (4 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
					VL_WRITEF("Not an Instruction!\n");
				    } else {
					if (VL_UNLIKELY(
							(2 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((1 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__rt1))) {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]bgez\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x23;
					    } else {
						if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
						    VL_WRITEF("[1]bltz\n\n");
						}
						vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x27;
					    }
					}
				    }
				}
			    }
			} else {
			    if ((0x20 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
				if (VL_UNLIKELY((0x10 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
				    VL_WRITEF("Not an Instruction!\n");
				} else {
				    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					if (VL_UNLIKELY(
							(4 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if (VL_LIKELY(
							  (2 
							   & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sltu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3f;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]slt\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x15;
						}
					    } else {
						VL_WRITEF("Not an Instruction!\n");
					    }
					}
				    } else {
					if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]nor\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xf;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]xor\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1f;
						}
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]or\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x10;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]and\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 4;
						}
					    }
					} else {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]subu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1e;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sub\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1d;
						}
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]addu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x37;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]add\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0;
						}
					    }
					}
				    }
				}
			    } else {
				if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
				    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					if (VL_UNLIKELY(
							(4 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]divu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 6;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]div\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 5;
						}
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]multu\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xd;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mult\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xd;
						}
					    }
					}
				    } else {
					if (VL_UNLIKELY(
							(4 
							 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
					    VL_WRITEF("Not an Instruction!\n");
					} else {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mtlo\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xc;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mflo\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xa;
						}
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mthi\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0xb;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]mfhi\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 9;
						}
					    }
					}
				    }
				} else {
				    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					    if (VL_UNLIKELY(
							    (2 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]break\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x13;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]syscal1\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
						}
					    }
					} else {
					    if (VL_UNLIKELY(
							    (2 
							     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						VL_WRITEF("Not an Instruction!\n");
					    } else {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]jalr\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 1;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]jr\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x3e;
						}
					    }
					}
				    } else {
					if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]srav\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1a;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]srlv\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1c;
						}
					    } else {
						if (VL_UNLIKELY(
								(1 
								 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						    VL_WRITEF("Not an Instruction!\n");
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sllv\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x14;
						}
					    }
					} else {
					    if ((2 
						 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						if (
						    (1 
						     & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1))) {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sra\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x19;
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]srl\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x1b;
						}
					    } else {
						if (VL_UNLIKELY(
								(1 
								 & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__funct1)))) {
						    VL_WRITEF("Not an Instruction!\n");
						} else {
						    if (VL_UNLIKELY(vlSymsp->TOP__v.comment1)) {
							VL_WRITEF("[1]sll,nop\n\n");
						    }
						    vlSymsp->TOP__v.__PVT__ID1__DOT__link1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jump1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__branch1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemRead1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemtoReg1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__MemWrite1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALUSrc1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__RegWrite1 = 1;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1 = 0;
						    vlSymsp->TOP__v.__PVT__ID1__DOT__ALU_control1 = 0x13;
						}
					    }
					}
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
    vlSymsp->TOP__v.__PVT__ID1__DOT__signExtended_output1 
	= ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1)
	    ? ((0xffff0000 & (VL_NEGATE_I((IData)((1 
						   & (vlSymsp->TOP__v.__PVT__Instr1_IF 
						      >> 0xf)))) 
			      << 0x10)) | (0xffff & vlSymsp->TOP__v.__PVT__Instr1_IF))
	    : (0xffff & vlSymsp->TOP__v.__PVT__Instr1_IF));
    vlSymsp->TOP__v.__PVT__ID1__DOT__writeRegister1 
	= (0x1f & ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1)
		    ? (vlSymsp->TOP__v.__PVT__Instr1_IF 
		       >> 0xb) : ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__link1)
				   ? 0x1f : ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1)
					      ? 0 : 
					     (vlSymsp->TOP__v.__PVT__Instr1_IF 
					      >> 0x10)))));
}

void VMIPS_MIPS::_sequent__TOP__v__6(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_sequent__TOP__v__6\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v.__PVT__writeRegister1_WB = vlSymsp->TOP__v.__Vdly__writeRegister1_WB;
    vlSymsp->TOP__v.__PVT__do_writeback1_WB = vlSymsp->TOP__v.__Vdly__do_writeback1_WB;
    vlSymsp->TOP__v.__PVT__writeData1_WB = ((IData)(vlSymsp->TOP__v.__PVT__MemtoReg1_MEM)
					     ? vlSymsp->TOP__v.__PVT__MemData1
					     : vlSymsp->TOP__v.__PVT__aluResult1_WB);
}

void VMIPS_MIPS::_sequent__TOP__v__7(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_sequent__TOP__v__7\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v.__PVT__ID1__DOT__signExtended_output1 
	= ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__sign_or_zero_Flag1)
	    ? ((0xffff0000 & (VL_NEGATE_I((IData)((1 
						   & (vlSymsp->TOP__v.__PVT__Instr1_IF 
						      >> 0xf)))) 
			      << 0x10)) | (0xffff & vlSymsp->TOP__v.__PVT__Instr1_IF))
	    : (0xffff & vlSymsp->TOP__v.__PVT__Instr1_IF));
    vlSymsp->TOP__v.__PVT__ID1__DOT__writeRegister1 
	= (0x1f & ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__RegDst1)
		    ? (vlSymsp->TOP__v.__PVT__Instr1_IF 
		       >> 0xb) : ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__link1)
				   ? 0x1f : ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1)
					      ? 0 : 
					     (vlSymsp->TOP__v.__PVT__Instr1_IF 
					      >> 0x10)))));
}

void VMIPS_MIPS::_multiclk__TOP__v__8(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_multiclk__TOP__v__8\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal_stop = 
	((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1) 
	 & ((((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_EXE) 
	      | (IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM)) 
	     | (IData)(vlSymsp->TOP__v.__PVT__MemtoReg1_EXE)) 
	    | (IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB)));
    vlSymsp->TOP__v.data_write_2DM = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
				       & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB) 
					  == (IData)(vlSymsp->TOP__v.__PVT__readRegisterB1_EXE)))
				       ? vlSymsp->TOP__v.__PVT__writeData1_WB
				       : (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_DST) 
					   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_DST) 
					      == (IData)(vlSymsp->TOP__v.__PVT__readRegisterB1_EXE)))
					   ? vlSymsp->TOP__v.__PVT__writeData1_DST
					   : vlSymsp->TOP__v.__PVT__readDataB1_EXE));
    vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
					       & ((IData)(vlSymsp->TOP__v.__PVT__readRegisterA1_ID) 
						  == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM)))
					       ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
					       : (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__readRegisterA1_ID) 
						      == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB)))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : 
						  (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_DST) 
						    & ((IData)(vlSymsp->TOP__v.__PVT__readRegisterA1_ID) 
						       == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_DST)))
						    ? vlSymsp->TOP__v.__PVT__writeData1_DST
						    : vlSymsp->TOP__v.__PVT__OpA)));
    vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
					       & ((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpRegisterB1) 
						  == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM)))
					       ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
					       : (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpRegisterB1) 
						      == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB)))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : 
						  (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_DST) 
						    & ((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpRegisterB1) 
						       == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_DST)))
						    ? vlSymsp->TOP__v.__PVT__writeData1_DST
						    : vlSymsp->TOP__v.__PVT__OpB)));
    vlSymsp->TOP__v.Instr_address_2IM = ((IData)(vlSymsp->TOP__v.__PVT__taken_branch1_ID)
					  ? ((IData)(vlSymsp->TOP__v.__PVT__jumpR)
					      ? (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
						  & ((IData)(vlSymsp->TOP__v.__PVT__jumpRegister) 
						     == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM)))
						  ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
						  : 
						 (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__jumpRegister) 
						      == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB)))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : vlSymsp->TOP__v.__PVT__tempInstruction_address))
					      : vlSymsp->TOP__v.__PVT__tempInstruction_address)
					  : vlSymsp->TOP__v.__PVT__IF1__DOT__PC);
    vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1 = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
						  & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM) 
						     == 
						     (0x1f 
						      & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							 >> 0x15))))
						  ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
						  : 
						 (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB) 
						      == 
						      (0x1f 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x15))))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : vlSymsp->TOP__v.__PVT__ID1__DOT__readDataA1));
    vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpB1 = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
						  & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM) 
						     == 
						     (0x1f 
						      & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							 >> 0x10))))
						  ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
						  : 
						 (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB) 
						      == 
						      (0x1f 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x10))))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : vlSymsp->TOP__v.__PVT__ID1__DOT__readDataB1));
}

void VMIPS_MIPS::_settle__TOP__v__9(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_settle__TOP__v__9\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v.__PVT__ID1__DOT__syscal_stop = 
	((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1) 
	 & ((((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_EXE) 
	      | (IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM)) 
	     | (IData)(vlSymsp->TOP__v.__PVT__MemtoReg1_EXE)) 
	    | (IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB)));
    vlSymsp->TOP__v.data_write_2DM = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
				       & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB) 
					  == (IData)(vlSymsp->TOP__v.__PVT__readRegisterB1_EXE)))
				       ? vlSymsp->TOP__v.__PVT__writeData1_WB
				       : (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_DST) 
					   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_DST) 
					      == (IData)(vlSymsp->TOP__v.__PVT__readRegisterB1_EXE)))
					   ? vlSymsp->TOP__v.__PVT__writeData1_DST
					   : vlSymsp->TOP__v.__PVT__readDataB1_EXE));
    vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
					       & ((IData)(vlSymsp->TOP__v.__PVT__readRegisterA1_ID) 
						  == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM)))
					       ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
					       : (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__readRegisterA1_ID) 
						      == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB)))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : 
						  (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_DST) 
						    & ((IData)(vlSymsp->TOP__v.__PVT__readRegisterA1_ID) 
						       == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_DST)))
						    ? vlSymsp->TOP__v.__PVT__writeData1_DST
						    : vlSymsp->TOP__v.__PVT__OpA)));
    vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
					       & ((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpRegisterB1) 
						  == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM)))
					       ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
					       : (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpRegisterB1) 
						      == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB)))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : 
						  (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_DST) 
						    & ((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpRegisterB1) 
						       == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_DST)))
						    ? vlSymsp->TOP__v.__PVT__writeData1_DST
						    : vlSymsp->TOP__v.__PVT__OpB)));
    vlSymsp->TOP__v.Instr_address_2IM = ((IData)(vlSymsp->TOP__v.__PVT__taken_branch1_ID)
					  ? ((IData)(vlSymsp->TOP__v.__PVT__jumpR)
					      ? (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
						  & ((IData)(vlSymsp->TOP__v.__PVT__jumpRegister) 
						     == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM)))
						  ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
						  : 
						 (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__jumpRegister) 
						      == (IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB)))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : vlSymsp->TOP__v.__PVT__tempInstruction_address))
					      : vlSymsp->TOP__v.__PVT__tempInstruction_address)
					  : vlSymsp->TOP__v.__PVT__IF1__DOT__PC);
    vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpA1 = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
						  & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM) 
						     == 
						     (0x1f 
						      & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							 >> 0x15))))
						  ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
						  : 
						 (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB) 
						      == 
						      (0x1f 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x15))))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : vlSymsp->TOP__v.__PVT__ID1__DOT__readDataA1));
    vlSymsp->TOP__v.__PVT__ID1__DOT__com_OpB1 = (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_MEM) 
						  & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM) 
						     == 
						     (0x1f 
						      & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							 >> 0x10))))
						  ? vlSymsp->TOP__v.__PVT__aluResult1_MEM
						  : 
						 (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_WB) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_WB) 
						      == 
						      (0x1f 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x10))))
						   ? vlSymsp->TOP__v.__PVT__writeData1_WB
						   : vlSymsp->TOP__v.__PVT__ID1__DOT__readDataB1));
    vlSymsp->TOP__v.SYS = ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1) 
			   & (~ (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal_stop)));
    vlSymsp->TOP__v.__PVT__no_new_fetch = ((((((~ (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1)) 
					       & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jump1)) 
					      | (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__branch1)) 
					     & (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_EXE) 
						 & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_ID) 
						    == 
						    (0x1f 
						     & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							>> 0x15)))) 
						| ((IData)(vlSymsp->TOP__v.__PVT__MemtoReg1_EXE) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM) 
						      == 
						      (0x1f 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x15)))))) 
					    | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__branch1) 
						& ((5 
						    == 
						    (7 
						     & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							>> 0x1a))) 
						   | (4 
						      == 
						      (7 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x1a))))) 
					       & (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_EXE) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_ID) 
						      == 
						      (0x1f 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x10)))) 
						  | ((IData)(vlSymsp->TOP__v.__PVT__MemtoReg1_EXE) 
						     & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM) 
							== 
							(0x1f 
							 & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							    >> 0x10))))))) 
					   | (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal_stop));
    // ALWAYS at MEM.v:95
    if ((0x20 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
	if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
	    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
		= vlTOPp->data_read_fDM;
	} else {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				= vlTOPp->data_read_fDM;
			} else {
			    if ((0 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = ((0xffffff00 
					& vlSymsp->TOP__v.data_write_2DM) 
				       | (0xff & (vlTOPp->data_read_fDM 
						  >> 0x18)));
			    } else {
				if ((1 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= ((0xffff0000 
					    & vlSymsp->TOP__v.data_write_2DM) 
					   | (0xffff 
					      & (vlTOPp->data_read_fDM 
						 >> 0x10)));
				} else {
				    if ((2 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					    = ((0xff000000 
						& vlSymsp->TOP__v.data_write_2DM) 
					       | (0xffffff 
						  & (vlTOPp->data_read_fDM 
						     >> 8)));
				    } else {
					if ((3 == (3 
						   & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
						= vlTOPp->data_read_fDM;
					}
				    }
				}
			    }
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			    if ((0 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = vlTOPp->data_read_fDM;
			    } else {
				if ((1 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= ((0xffffff00 
					    & (vlTOPp->data_read_fDM 
					       << 8)) 
					   | (0xff 
					      & vlSymsp->TOP__v.data_write_2DM));
				} else {
				    if ((2 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					    = ((0xffff0000 
						& (vlTOPp->data_read_fDM 
						   << 0x10)) 
					       | (0xffff 
						  & vlSymsp->TOP__v.data_write_2DM));
				    } else {
					if ((3 == (3 
						   & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
						= (
						   (0xff000000 
						    & (vlTOPp->data_read_fDM 
						       << 0x18)) 
						   | (0xffffff 
						      & vlSymsp->TOP__v.data_write_2DM));
					}
				    }
				}
			    }
			} else {
			    if ((0 == VL_MODDIV_III(32, vlSymsp->TOP__v.__PVT__aluResult1_MEM, (IData)(4)))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = (0xffff & vlTOPp->data_read_fDM);
			    } else {
				if (VL_LIKELY((2 == 
					       VL_MODDIV_III(32, vlSymsp->TOP__v.__PVT__aluResult1_MEM, (IData)(4))))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= (0xffff & 
					   (vlTOPp->data_read_fDM 
					    >> 0x10));
				} else {
				    VL_WRITEF("Address Exceptions!!!!!!#################\n");
				}
			    }
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			    if ((0 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = ((0xffff0000 
					& (VL_NEGATE_I((IData)(
							       (1 
								& (vlTOPp->data_read_fDM 
								   >> 0xf)))) 
					   << 0x10)) 
				       | (0xffff & vlTOPp->data_read_fDM));
			    } else {
				if (VL_LIKELY((2 == 
					       (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM)))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= ((0xffff0000 
					    & (VL_NEGATE_I((IData)(
								   (1 
								    & (vlTOPp->data_read_fDM 
								       >> 0x1f)))) 
					       << 0x10)) 
					   | (0xffff 
					      & (vlTOPp->data_read_fDM 
						 >> 0x10)));
				} else {
				    VL_WRITEF("Address Exceptions!!!!!!#################\n");
				}
			    }
			} else {
			    if ((0 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = (0xff & (vlTOPp->data_read_fDM 
					       >> 0x18));
			    } else {
				if ((1 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= (0xff & (vlTOPp->data_read_fDM 
						   >> 0x10));
				} else {
				    if ((2 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					    = (0xff 
					       & (vlTOPp->data_read_fDM 
						  >> 8));
				    } else {
					if ((3 == (3 
						   & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
						= (0xff 
						   & vlTOPp->data_read_fDM);
					}
				    }
				}
			    }
			}
		    } else {
			vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
			    = vlTOPp->data_read_fDM;
		    }
		}
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
		    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
			= vlTOPp->data_read_fDM;
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
			    = vlTOPp->data_read_fDM;
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			    if ((3 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = ((0xffffff00 
					& (VL_NEGATE_I((IData)(
							       (1 
								& (vlTOPp->data_read_fDM 
								   >> 7)))) 
					   << 8)) | 
				       (0xff & vlTOPp->data_read_fDM));
			    } else {
				if ((2 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= ((0xffffff00 
					    & (VL_NEGATE_I((IData)(
								   (1 
								    & (vlTOPp->data_read_fDM 
								       >> 0xf)))) 
					       << 8)) 
					   | (0xff 
					      & (vlTOPp->data_read_fDM 
						 >> 8)));
				} else {
				    if ((1 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					    = ((0xffffff00 
						& (VL_NEGATE_I((IData)(
								       (1 
									& (vlTOPp->data_read_fDM 
									   >> 0x17)))) 
						   << 8)) 
					       | (0xff 
						  & (vlTOPp->data_read_fDM 
						     >> 0x10)));
				    } else {
					if ((0 == (3 
						   & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
						= (
						   (0xffffff00 
						    & (VL_NEGATE_I((IData)(
									   (1 
									    & (vlTOPp->data_read_fDM 
									       >> 0x1f)))) 
						       << 8)) 
						   | (0xff 
						      & (vlTOPp->data_read_fDM 
							 >> 0x18)));
					}
				    }
				}
			    }
			} else {
			    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				= vlTOPp->data_read_fDM;
			}
		    }
		}
	    }
	}
    } else {
	vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
	    = vlTOPp->data_read_fDM;
    }
    // ALWAYS at ALU.v:18
    if ((0x20 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
	vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
	    = ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
	        ? ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		    ? ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		        ? ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? ((vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				    > vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
				    ? 0 : ((vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					    == vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
					    ? 0 : 1))
			        : 0) : ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
					 ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					    + ((0xffff0000 
						& (VL_NEGATE_I((IData)(
								       (1 
									& (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
									   >> 0xf)))) 
						   << 0x10)) 
					       | (0xffff 
						  & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
					 : 0)) : ((2 
						   & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						   ? 0
						   : 
						  ((1 
						    & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						    ? 
						   (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						    + 
						    ((0xffff0000 
						      & (VL_NEGATE_I((IData)(
									     (1 
									      & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
										>> 0xf)))) 
							 << 0x10)) 
						     | (0xffff 
							& vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
						    : vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
		    : ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		        ? ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   + vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
			        : 0) : ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
					 ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					    + vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
					 : vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))
		        : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
			   + ((0xffff0000 & (VL_NEGATE_I((IData)(
								 (1 
								  & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
								     >> 0xf)))) 
					     << 0x10)) 
			      | (0xffff & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))))
	        : ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		    ? ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		        ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
			   + ((0xffff0000 & (VL_NEGATE_I((IData)(
								 (1 
								  & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
								     >> 0xf)))) 
					     << 0x10)) 
			      | (0xffff & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
		        : ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
			       + ((0xffff0000 & (VL_NEGATE_I((IData)(
								     (1 
								      & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
									 >> 0xf)))) 
						 << 0x10)) 
				  | (0xffff & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
			    : 0)) : ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
				      ? 0 : ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
					      ? 0 : 
					     ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
					       ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						  + 
						  ((0xffff0000 
						    & (VL_NEGATE_I((IData)(
									   (1 
									    & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
									       >> 0xf)))) 
						       << 0x10)) 
						   | (0xffff 
						      & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
					       : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						  ^ vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))))));
    } else {
	if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
			    = ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   ^ vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
			        : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   - vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1));
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   - vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1);
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((VL_ULL(0xffffffff00000000) 
				    & vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				   | (IData)((IData)(
						     (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
						      >> 
						      (0x1f 
						       & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1)))));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp);
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
				   >> (IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID));
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((VL_ULL(0xfffffffe00000000) 
				    & vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				   | (((QData)((IData)(
						       (1 
							& (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
							   >> 0x1f)))) 
				       << 0x20) | (QData)((IData)(
								  (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
								   >> 
								   (0x1f 
								    & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1))))));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i = 0;
			    while (((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i) 
				    <= (0x1f & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1))) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = (((~ (VL_ULL(1) 
					    << (0x3f 
						& ((IData)(0x1f) 
						   - (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i))))) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << (0x3f 
					      & ((IData)(0x1f) 
						 - (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i)))));
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i 
				    = (0x1f & ((IData)(1) 
					       + (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i)));
			    }
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp);
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((VL_ULL(0xfffffffe00000000) 
				    & vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				   | (((QData)((IData)(
						       (1 
							& (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
							   >> 0x1f)))) 
				       << 0x20) | (QData)((IData)(
								  (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
								   >> (IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID))))));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((VL_ULL(0xffffffff7fffffff) 
				    & vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				   | ((QData)((IData)(
						      (1 
						       & (IData)(
								 (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								  >> 0x20))))) 
				      << 0x1f));
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 1)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffbfffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1e));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 2)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffdfffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1d));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 3)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffefffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1c));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 4)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffff7ffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1b));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 5)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffbffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1a));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 6)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffdffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x19));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 7)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffeffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x18));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 8)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffff7fffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x17));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 9)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffbfffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x16));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xa)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffdfffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x15));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xb)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffefffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x14));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xc)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffff7ffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x13));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xd)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffbffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x12));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xe)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffdffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x11));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xf)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffeffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x10));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x10)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffff7fff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xf));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x11)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffbfff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xe));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x12)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffdfff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xd));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x13)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffefff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xc));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x14)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffff7ff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xb));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x15)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffbff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xa));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x16)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffdff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 9));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x17)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffeff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 8));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x18)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffff7f) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 7));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x19)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffffbf) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 6));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1a)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffffdf) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 5));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1b)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffffef) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 4));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1c)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffff7) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 3));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1d)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffffb) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 2));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1e)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffffd) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 1));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1f)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffffe) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | (IData)((IData)(
							 (1 
							  & (IData)(
								    (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								     >> 0x20))))));
			    }
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp);
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 = 0;
			}
		    }
		}
	    } else {
		vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
		    = ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		        ? ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? 0 : ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
				    ? (((1 & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					      >> 0x1f)) 
					< (1 & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
						>> 0x1f)))
				        ? 0 : (((0x7fffffff 
						 & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1) 
						> (0x7fffffff 
						   & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))
					        ? 0
					        : (
						   (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						    == vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
						    ? 0
						    : 1)))
				    : ((vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					<= 0x1f) ? 
				       (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
					<< vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1)
				        : 0))) : ((2 
						   & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						   ? 
						  ((1 
						    & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						    ? 
						   (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
						    << (IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID))
						    : 0)
						   : 
						  ((1 
						    & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						    ? 0
						    : 
						   (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						    | vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))));
	    }
	} else {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
			    = ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? (~ (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				      | vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))
			        : 0);
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((QData)((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1)) 
				   * (QData)((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__HI 
				= (IData)((vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
					   >> 0x20));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__LO 
				= (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp);
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__LO 
				= vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1;
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__HI 
				= vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1;
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= vlSymsp->TOP__v.__PVT__EXE1__DOT__LO;
			}
		    } else {
			vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
			    = ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? vlSymsp->TOP__v.__PVT__EXE1__DOT__HI
			        : (0xffff0000 & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
						 << 0x10)));
		    }
		}
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 = 0;
			} else {
			    if ((0 != vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__LO 
				    = VL_DIV_III(32, vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1, vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1);
				vlSymsp->TOP__v.__PVT__EXE1__DOT__HI 
				    = VL_MODDIV_III(32, vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1, vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1);
			    }
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    if ((0 != vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__LO 
				    = ((0x80000000 
					& (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					   | vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)) 
				       | (0x7fffffff 
					  & VL_DIV_III(31, 
						       (0x7fffffff 
							& vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1), 
						       (0x7fffffff 
							& vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))));
				vlSymsp->TOP__v.__PVT__EXE1__DOT__HI 
				    = ((0x80000000 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__HI) 
				       | (0x7fffffff 
					  & VL_MODDIV_III(31, 
							  (0x7fffffff 
							   & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1), 
							  (0x7fffffff 
							   & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))));
			    }
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1);
			}
		    }
		} else {
		    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
			= ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? 0 : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				       + vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))
			    : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
			       + vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1));
		}
	    }
	}
    }
}

void VMIPS_MIPS::_multiclk__TOP__v__10(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_multiclk__TOP__v__10\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v.SYS = ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal1) 
			   & (~ (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal_stop)));
    vlSymsp->TOP__v.__PVT__no_new_fetch = ((((((~ (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jumpRegister_Flag1)) 
					       & (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__jump1)) 
					      | (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__branch1)) 
					     & (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_EXE) 
						 & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_ID) 
						    == 
						    (0x1f 
						     & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							>> 0x15)))) 
						| ((IData)(vlSymsp->TOP__v.__PVT__MemtoReg1_EXE) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM) 
						      == 
						      (0x1f 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x15)))))) 
					    | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__branch1) 
						& ((5 
						    == 
						    (7 
						     & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							>> 0x1a))) 
						   | (4 
						      == 
						      (7 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x1a))))) 
					       & (((IData)(vlSymsp->TOP__v.__PVT__do_writeback1_EXE) 
						   & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_ID) 
						      == 
						      (0x1f 
						       & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							  >> 0x10)))) 
						  | ((IData)(vlSymsp->TOP__v.__PVT__MemtoReg1_EXE) 
						     & ((IData)(vlSymsp->TOP__v.__PVT__writeRegister1_MEM) 
							== 
							(0x1f 
							 & (vlSymsp->TOP__v.__PVT__Instr1_IF 
							    >> 0x10))))))) 
					   | (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__syscal_stop));
    // ALWAYS at ALU.v:18
    if ((0x20 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
	vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
	    = ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
	        ? ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		    ? ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		        ? ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? ((vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				    > vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
				    ? 0 : ((vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					    == vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
					    ? 0 : 1))
			        : 0) : ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
					 ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					    + ((0xffff0000 
						& (VL_NEGATE_I((IData)(
								       (1 
									& (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
									   >> 0xf)))) 
						   << 0x10)) 
					       | (0xffff 
						  & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
					 : 0)) : ((2 
						   & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						   ? 0
						   : 
						  ((1 
						    & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						    ? 
						   (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						    + 
						    ((0xffff0000 
						      & (VL_NEGATE_I((IData)(
									     (1 
									      & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
										>> 0xf)))) 
							 << 0x10)) 
						     | (0xffff 
							& vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
						    : vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
		    : ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		        ? ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   + vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
			        : 0) : ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
					 ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					    + vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
					 : vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))
		        : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
			   + ((0xffff0000 & (VL_NEGATE_I((IData)(
								 (1 
								  & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
								     >> 0xf)))) 
					     << 0x10)) 
			      | (0xffff & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))))
	        : ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		    ? ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		        ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
			   + ((0xffff0000 & (VL_NEGATE_I((IData)(
								 (1 
								  & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
								     >> 0xf)))) 
					     << 0x10)) 
			      | (0xffff & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
		        : ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
			       + ((0xffff0000 & (VL_NEGATE_I((IData)(
								     (1 
								      & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
									 >> 0xf)))) 
						 << 0x10)) 
				  | (0xffff & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
			    : 0)) : ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
				      ? 0 : ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
					      ? 0 : 
					     ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
					       ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						  + 
						  ((0xffff0000 
						    & (VL_NEGATE_I((IData)(
									   (1 
									    & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
									       >> 0xf)))) 
						       << 0x10)) 
						   | (0xffff 
						      & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)))
					       : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						  ^ vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))))));
    } else {
	if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
			    = ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   ^ vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
			        : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   - vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1));
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   - vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1);
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((VL_ULL(0xffffffff00000000) 
				    & vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				   | (IData)((IData)(
						     (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
						      >> 
						      (0x1f 
						       & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1)))));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp);
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
				   >> (IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID));
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((VL_ULL(0xfffffffe00000000) 
				    & vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				   | (((QData)((IData)(
						       (1 
							& (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
							   >> 0x1f)))) 
				       << 0x20) | (QData)((IData)(
								  (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
								   >> 
								   (0x1f 
								    & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1))))));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i = 0;
			    while (((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i) 
				    <= (0x1f & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1))) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = (((~ (VL_ULL(1) 
					    << (0x3f 
						& ((IData)(0x1f) 
						   - (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i))))) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << (0x3f 
					      & ((IData)(0x1f) 
						 - (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i)))));
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i 
				    = (0x1f & ((IData)(1) 
					       + (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__i)));
			    }
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp);
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((VL_ULL(0xfffffffe00000000) 
				    & vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				   | (((QData)((IData)(
						       (1 
							& (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
							   >> 0x1f)))) 
				       << 0x20) | (QData)((IData)(
								  (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
								   >> (IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID))))));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((VL_ULL(0xffffffff7fffffff) 
				    & vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				   | ((QData)((IData)(
						      (1 
						       & (IData)(
								 (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								  >> 0x20))))) 
				      << 0x1f));
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 1)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffbfffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1e));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 2)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffdfffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1d));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 3)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffefffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1c));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 4)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffff7ffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1b));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 5)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffbffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x1a));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 6)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffdffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x19));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 7)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffeffffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x18));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 8)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffff7fffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x17));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 9)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffbfffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x16));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xa)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffdfffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x15));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xb)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffefffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x14));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xc)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffff7ffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x13));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xd)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffbffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x12));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xe)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffdffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x11));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0xf)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffeffff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0x10));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x10)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffff7fff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xf));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x11)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffbfff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xe));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x12)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffdfff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xd));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x13)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffefff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xc));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x14)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffff7ff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xb));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x15)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffbff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 0xa));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x16)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffdff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 9));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x17)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffeff) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 8));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x18)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffff7f) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 7));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x19)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffffbf) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 6));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1a)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffffdf) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 5));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1b)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xffffffffffffffef) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 4));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1c)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffff7) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 3));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1d)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffffb) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 2));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1e)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffffd) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | ((QData)((IData)(
							  (1 
							   & (IData)(
								     (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								      >> 0x20))))) 
					  << 1));
			    }
			    if (((IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID) 
				 >= 0x1f)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				    = ((VL_ULL(0xfffffffffffffffe) 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp) 
				       | (IData)((IData)(
							 (1 
							  & (IData)(
								    (vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
								     >> 0x20))))));
			    }
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp);
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 = 0;
			}
		    }
		}
	    } else {
		vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
		    = ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
		        ? ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? 0 : ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
				    ? (((1 & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					      >> 0x1f)) 
					< (1 & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
						>> 0x1f)))
				        ? 0 : (((0x7fffffff 
						 & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1) 
						> (0x7fffffff 
						   & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))
					        ? 0
					        : (
						   (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						    == vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)
						    ? 0
						    : 1)))
				    : ((vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					<= 0x1f) ? 
				       (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
					<< vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1)
				        : 0))) : ((2 
						   & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						   ? 
						  ((1 
						    & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						    ? 
						   (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
						    << (IData)(vlSymsp->TOP__v.__PVT__Instr1_10_6_ID))
						    : 0)
						   : 
						  ((1 
						    & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
						    ? 0
						    : 
						   (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
						    | vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))));
	    }
	} else {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
			    = ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? (~ (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				      | vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))
			        : 0);
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
				= ((QData)((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1)) 
				   * (QData)((IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__HI 
				= (IData)((vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp 
					   >> 0x20));
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__LO 
				= (IData)(vlSymsp->TOP__v.__PVT__EXE1__DOT__ALU1__DOT__temp);
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__LO 
				= vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1;
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__HI 
				= vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1;
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= vlSymsp->TOP__v.__PVT__EXE1__DOT__LO;
			}
		    } else {
			vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
			    = ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? vlSymsp->TOP__v.__PVT__EXE1__DOT__HI
			        : (0xffff0000 & (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1 
						 << 0x10)));
		    }
		}
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 = 0;
			} else {
			    if ((0 != vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__LO 
				    = VL_DIV_III(32, vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1, vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1);
				vlSymsp->TOP__v.__PVT__EXE1__DOT__HI 
				    = VL_MODDIV_III(32, vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1, vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1);
			    }
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))) {
			    if ((0 != vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)) {
				vlSymsp->TOP__v.__PVT__EXE1__DOT__LO 
				    = ((0x80000000 
					& (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
					   | vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1)) 
				       | (0x7fffffff 
					  & VL_DIV_III(31, 
						       (0x7fffffff 
							& vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1), 
						       (0x7fffffff 
							& vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))));
				vlSymsp->TOP__v.__PVT__EXE1__DOT__HI 
				    = ((0x80000000 
					& vlSymsp->TOP__v.__PVT__EXE1__DOT__HI) 
				       | (0x7fffffff 
					  & VL_MODDIV_III(31, 
							  (0x7fffffff 
							   & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1), 
							  (0x7fffffff 
							   & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))));
			    }
			} else {
			    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
				= (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				   & vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1);
			}
		    }
		} else {
		    vlSymsp->TOP__v.__PVT__EXE1__DOT__aluResult1 
			= ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			    ? ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_ID))
			        ? 0 : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
				       + vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1))
			    : (vlSymsp->TOP__v.__PVT__EXE1__DOT__OpA1 
			       + vlSymsp->TOP__v.__PVT__EXE1__DOT__OpB1));
		}
	    }
	}
    }
}

void VMIPS_MIPS::_combo__TOP__v__11(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("      VMIPS_MIPS::_combo__TOP__v__11\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // ALWAYS at MEM.v:95
    if ((0x20 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
	if ((0x10 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
	    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
		= vlTOPp->data_read_fDM;
	} else {
	    if ((8 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				= vlTOPp->data_read_fDM;
			} else {
			    if ((0 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = ((0xffffff00 
					& vlSymsp->TOP__v.data_write_2DM) 
				       | (0xff & (vlTOPp->data_read_fDM 
						  >> 0x18)));
			    } else {
				if ((1 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= ((0xffff0000 
					    & vlSymsp->TOP__v.data_write_2DM) 
					   | (0xffff 
					      & (vlTOPp->data_read_fDM 
						 >> 0x10)));
				} else {
				    if ((2 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					    = ((0xff000000 
						& vlSymsp->TOP__v.data_write_2DM) 
					       | (0xffffff 
						  & (vlTOPp->data_read_fDM 
						     >> 8)));
				    } else {
					if ((3 == (3 
						   & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
						= vlTOPp->data_read_fDM;
					}
				    }
				}
			    }
			}
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			    if ((0 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = vlTOPp->data_read_fDM;
			    } else {
				if ((1 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= ((0xffffff00 
					    & (vlTOPp->data_read_fDM 
					       << 8)) 
					   | (0xff 
					      & vlSymsp->TOP__v.data_write_2DM));
				} else {
				    if ((2 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					    = ((0xffff0000 
						& (vlTOPp->data_read_fDM 
						   << 0x10)) 
					       | (0xffff 
						  & vlSymsp->TOP__v.data_write_2DM));
				    } else {
					if ((3 == (3 
						   & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
						= (
						   (0xff000000 
						    & (vlTOPp->data_read_fDM 
						       << 0x18)) 
						   | (0xffffff 
						      & vlSymsp->TOP__v.data_write_2DM));
					}
				    }
				}
			    }
			} else {
			    if ((0 == VL_MODDIV_III(32, vlSymsp->TOP__v.__PVT__aluResult1_MEM, (IData)(4)))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = (0xffff & vlTOPp->data_read_fDM);
			    } else {
				if (VL_LIKELY((2 == 
					       VL_MODDIV_III(32, vlSymsp->TOP__v.__PVT__aluResult1_MEM, (IData)(4))))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= (0xffff & 
					   (vlTOPp->data_read_fDM 
					    >> 0x10));
				} else {
				    VL_WRITEF("Address Exceptions!!!!!!#################\n");
				}
			    }
			}
		    }
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			    if ((0 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = ((0xffff0000 
					& (VL_NEGATE_I((IData)(
							       (1 
								& (vlTOPp->data_read_fDM 
								   >> 0xf)))) 
					   << 0x10)) 
				       | (0xffff & vlTOPp->data_read_fDM));
			    } else {
				if (VL_LIKELY((2 == 
					       (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM)))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= ((0xffff0000 
					    & (VL_NEGATE_I((IData)(
								   (1 
								    & (vlTOPp->data_read_fDM 
								       >> 0x1f)))) 
					       << 0x10)) 
					   | (0xffff 
					      & (vlTOPp->data_read_fDM 
						 >> 0x10)));
				} else {
				    VL_WRITEF("Address Exceptions!!!!!!#################\n");
				}
			    }
			} else {
			    if ((0 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = (0xff & (vlTOPp->data_read_fDM 
					       >> 0x18));
			    } else {
				if ((1 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= (0xff & (vlTOPp->data_read_fDM 
						   >> 0x10));
				} else {
				    if ((2 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					    = (0xff 
					       & (vlTOPp->data_read_fDM 
						  >> 8));
				    } else {
					if ((3 == (3 
						   & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
						= (0xff 
						   & vlTOPp->data_read_fDM);
					}
				    }
				}
			    }
			}
		    } else {
			vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
			    = vlTOPp->data_read_fDM;
		    }
		}
	    } else {
		if ((4 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
		    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
			= vlTOPp->data_read_fDM;
		} else {
		    if ((2 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
			    = vlTOPp->data_read_fDM;
		    } else {
			if ((1 & (IData)(vlSymsp->TOP__v.__PVT__ALU_control1_EXE))) {
			    if ((3 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				    = ((0xffffff00 
					& (VL_NEGATE_I((IData)(
							       (1 
								& (vlTOPp->data_read_fDM 
								   >> 7)))) 
					   << 8)) | 
				       (0xff & vlTOPp->data_read_fDM));
			    } else {
				if ((2 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
				    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					= ((0xffffff00 
					    & (VL_NEGATE_I((IData)(
								   (1 
								    & (vlTOPp->data_read_fDM 
								       >> 0xf)))) 
					       << 8)) 
					   | (0xff 
					      & (vlTOPp->data_read_fDM 
						 >> 8)));
				} else {
				    if ((1 == (3 & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
					    = ((0xffffff00 
						& (VL_NEGATE_I((IData)(
								       (1 
									& (vlTOPp->data_read_fDM 
									   >> 0x17)))) 
						   << 8)) 
					       | (0xff 
						  & (vlTOPp->data_read_fDM 
						     >> 0x10)));
				    } else {
					if ((0 == (3 
						   & vlSymsp->TOP__v.__PVT__aluResult1_MEM))) {
					    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
						= (
						   (0xffffff00 
						    & (VL_NEGATE_I((IData)(
									   (1 
									    & (vlTOPp->data_read_fDM 
									       >> 0x1f)))) 
						       << 8)) 
						   | (0xff 
						      & (vlTOPp->data_read_fDM 
							 >> 0x18)));
					}
				    }
				}
			    }
			} else {
			    vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
				= vlTOPp->data_read_fDM;
			}
		    }
		}
	    }
	}
    } else {
	vlSymsp->TOP__v.__PVT__MEM1__DOT__data_read_aligned 
	    = vlTOPp->data_read_fDM;
    }
}
