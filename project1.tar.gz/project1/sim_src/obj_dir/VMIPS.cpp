// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VMIPS.h for the primary calling header

#include "VMIPS.h"             // For This
#include "VMIPS__Syms.h"

//--------------------
// STATIC VARIABLES


//--------------------

VL_CTOR_IMP(VMIPS) {
    VMIPS__Syms* __restrict vlSymsp = __VlSymsp = new VMIPS__Syms(this, name());
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    VL_CELL (v, VMIPS_MIPS);
    // Reset internal values
    
    // Reset structure values
    { int __Vi0=0; for (; __Vi0<32; ++__Vi0) {
	    Reg_ID[__Vi0] = VL_RAND_RESET_I(32);
    }}
    R2_output = VL_RAND_RESET_I(32);
    data_address_2DM = VL_RAND_RESET_I(32);
    data_write_2DM = VL_RAND_RESET_I(32);
    VL_RAND_RESET_W(256,block_write_2DM);
    VL_RAND_RESET_W(256,block_write_2IM);
    MemRead = VL_RAND_RESET_I(1);
    MemWrite = VL_RAND_RESET_I(1);
    iBlkRead = 0;
    iBlkWrite = 0;
    dBlkRead = 0;
    dBlkWrite = 0;
    PC_init = VL_RAND_RESET_I(32);
    R2_input = VL_RAND_RESET_I(32);
    data_read_fDM = VL_RAND_RESET_I(32);
    VL_RAND_RESET_W(256,block_read_fDM);
    VL_RAND_RESET_W(256,block_read_fIM);
    Instr1_fIM = VL_RAND_RESET_I(32);
    Instr2_fIM = VL_RAND_RESET_I(32);
    CLK = 0;
    RESET = 0;
    __Vclklast__TOP__CLK = 0;
    __Vclklast__TOP__RESET = 0;
}

void VMIPS::__Vconfigure(VMIPS__Syms* vlSymsp, bool first) {
    if (0 && first) {}  // Prevent unused
    this->__VlSymsp = vlSymsp;
}

VMIPS::~VMIPS() {
    delete __VlSymsp; __VlSymsp=NULL;
}

//--------------------


void VMIPS::eval() {
    VMIPS__Syms* __restrict vlSymsp = this->__VlSymsp; // Setup global symbol table
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // Evaluate till stable
    VL_DEBUG_IF(VL_PRINTF("\n----TOP Evaluate VMIPS::eval\n"); );
    int __VclockLoop = 0;
    IData __Vchange=1;
    while (VL_LIKELY(__Vchange)) {
	VL_DEBUG_IF(VL_PRINTF(" Clock loop\n"););
	vlSymsp->__Vm_activity = true;
	_eval(vlSymsp);
	__Vchange = _change_request(vlSymsp);
	if (++__VclockLoop > 100) vl_fatal(__FILE__,__LINE__,__FILE__,"Verilated model didn't converge");
    }
}

void VMIPS::_eval_initial_loop(VMIPS__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    _eval_initial(vlSymsp);
    vlSymsp->__Vm_activity = true;
    int __VclockLoop = 0;
    IData __Vchange=1;
    while (VL_LIKELY(__Vchange)) {
	_eval_settle(vlSymsp);
	_eval(vlSymsp);
	__Vchange = _change_request(vlSymsp);
	if (++__VclockLoop > 100) vl_fatal(__FILE__,__LINE__,__FILE__,"Verilated model didn't DC converge");
    }
}

//--------------------
// Internal Methods

void VMIPS::_settle__TOP__1(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_settle__TOP__1\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->dBlkWrite = vlSymsp->TOP__v.dBlkWrite;
    vlTOPp->dBlkRead = vlSymsp->TOP__v.dBlkRead;
    vlTOPp->iBlkWrite = vlSymsp->TOP__v.iBlkWrite;
    vlTOPp->iBlkRead = vlSymsp->TOP__v.iBlkRead;
    vlTOPp->block_write_2IM[0] = vlSymsp->TOP__v.block_write_2IM[0];
    vlTOPp->block_write_2IM[1] = vlSymsp->TOP__v.block_write_2IM[1];
    vlTOPp->block_write_2IM[2] = vlSymsp->TOP__v.block_write_2IM[2];
    vlTOPp->block_write_2IM[3] = vlSymsp->TOP__v.block_write_2IM[3];
    vlTOPp->block_write_2IM[4] = vlSymsp->TOP__v.block_write_2IM[4];
    vlTOPp->block_write_2IM[5] = vlSymsp->TOP__v.block_write_2IM[5];
    vlTOPp->block_write_2IM[6] = vlSymsp->TOP__v.block_write_2IM[6];
    vlTOPp->block_write_2IM[7] = vlSymsp->TOP__v.block_write_2IM[7];
    vlTOPp->block_write_2DM[0] = vlSymsp->TOP__v.block_write_2DM[0];
    vlTOPp->block_write_2DM[1] = vlSymsp->TOP__v.block_write_2DM[1];
    vlTOPp->block_write_2DM[2] = vlSymsp->TOP__v.block_write_2DM[2];
    vlTOPp->block_write_2DM[3] = vlSymsp->TOP__v.block_write_2DM[3];
    vlTOPp->block_write_2DM[4] = vlSymsp->TOP__v.block_write_2DM[4];
    vlTOPp->block_write_2DM[5] = vlSymsp->TOP__v.block_write_2DM[5];
    vlTOPp->block_write_2DM[6] = vlSymsp->TOP__v.block_write_2DM[6];
    vlTOPp->block_write_2DM[7] = vlSymsp->TOP__v.block_write_2DM[7];
}

void VMIPS::_sequent__TOP__2(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_sequent__TOP__2\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->R2_output = vlSymsp->TOP__v.R2_output;
}

void VMIPS::_sequent__TOP__3(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_sequent__TOP__3\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->Reg_ID[0x1f] = vlSymsp->TOP__v.Reg_ID[0x1f];
    vlTOPp->Reg_ID[0x1e] = vlSymsp->TOP__v.Reg_ID[0x1e];
    vlTOPp->Reg_ID[0x1d] = vlSymsp->TOP__v.Reg_ID[0x1d];
    vlTOPp->Reg_ID[0x1c] = vlSymsp->TOP__v.Reg_ID[0x1c];
    vlTOPp->Reg_ID[0x1b] = vlSymsp->TOP__v.Reg_ID[0x1b];
    vlTOPp->Reg_ID[0x1a] = vlSymsp->TOP__v.Reg_ID[0x1a];
    vlTOPp->Reg_ID[0x19] = vlSymsp->TOP__v.Reg_ID[0x19];
    vlTOPp->Reg_ID[0x18] = vlSymsp->TOP__v.Reg_ID[0x18];
    vlTOPp->Reg_ID[0x17] = vlSymsp->TOP__v.Reg_ID[0x17];
    vlTOPp->Reg_ID[0x16] = vlSymsp->TOP__v.Reg_ID[0x16];
    vlTOPp->Reg_ID[0x15] = vlSymsp->TOP__v.Reg_ID[0x15];
    vlTOPp->Reg_ID[0x14] = vlSymsp->TOP__v.Reg_ID[0x14];
    vlTOPp->Reg_ID[0x13] = vlSymsp->TOP__v.Reg_ID[0x13];
    vlTOPp->Reg_ID[0x12] = vlSymsp->TOP__v.Reg_ID[0x12];
    vlTOPp->Reg_ID[0x11] = vlSymsp->TOP__v.Reg_ID[0x11];
    vlTOPp->Reg_ID[0x10] = vlSymsp->TOP__v.Reg_ID[0x10];
    vlTOPp->Reg_ID[0] = vlSymsp->TOP__v.Reg_ID[0];
    vlTOPp->Reg_ID[1] = vlSymsp->TOP__v.Reg_ID[1];
    vlTOPp->Reg_ID[2] = vlSymsp->TOP__v.Reg_ID[2];
    vlTOPp->Reg_ID[3] = vlSymsp->TOP__v.Reg_ID[3];
    vlTOPp->Reg_ID[4] = vlSymsp->TOP__v.Reg_ID[4];
    vlTOPp->Reg_ID[5] = vlSymsp->TOP__v.Reg_ID[5];
    vlTOPp->Reg_ID[6] = vlSymsp->TOP__v.Reg_ID[6];
    vlTOPp->Reg_ID[7] = vlSymsp->TOP__v.Reg_ID[7];
    vlTOPp->Reg_ID[8] = vlSymsp->TOP__v.Reg_ID[8];
    vlTOPp->Reg_ID[9] = vlSymsp->TOP__v.Reg_ID[9];
    vlTOPp->Reg_ID[0xa] = vlSymsp->TOP__v.Reg_ID[0xa];
    vlTOPp->Reg_ID[0xb] = vlSymsp->TOP__v.Reg_ID[0xb];
    vlTOPp->Reg_ID[0xc] = vlSymsp->TOP__v.Reg_ID[0xc];
    vlTOPp->Reg_ID[0xd] = vlSymsp->TOP__v.Reg_ID[0xd];
    vlTOPp->Reg_ID[0xe] = vlSymsp->TOP__v.Reg_ID[0xe];
    vlTOPp->Reg_ID[0xf] = vlSymsp->TOP__v.Reg_ID[0xf];
}

void VMIPS::_settle__TOP__4(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_settle__TOP__4\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->R2_output = vlSymsp->TOP__v.R2_output;
    vlTOPp->Reg_ID[0x1f] = vlSymsp->TOP__v.Reg_ID[0x1f];
    vlTOPp->Reg_ID[0x1e] = vlSymsp->TOP__v.Reg_ID[0x1e];
    vlTOPp->Reg_ID[0x1d] = vlSymsp->TOP__v.Reg_ID[0x1d];
    vlTOPp->Reg_ID[0x1c] = vlSymsp->TOP__v.Reg_ID[0x1c];
    vlTOPp->Reg_ID[0x1b] = vlSymsp->TOP__v.Reg_ID[0x1b];
    vlTOPp->Reg_ID[0x1a] = vlSymsp->TOP__v.Reg_ID[0x1a];
    vlTOPp->Reg_ID[0x19] = vlSymsp->TOP__v.Reg_ID[0x19];
    vlTOPp->Reg_ID[0x18] = vlSymsp->TOP__v.Reg_ID[0x18];
    vlTOPp->Reg_ID[0x17] = vlSymsp->TOP__v.Reg_ID[0x17];
    vlTOPp->Reg_ID[0x16] = vlSymsp->TOP__v.Reg_ID[0x16];
    vlTOPp->Reg_ID[0x15] = vlSymsp->TOP__v.Reg_ID[0x15];
    vlTOPp->Reg_ID[0x14] = vlSymsp->TOP__v.Reg_ID[0x14];
    vlTOPp->Reg_ID[0x13] = vlSymsp->TOP__v.Reg_ID[0x13];
    vlTOPp->Reg_ID[0x12] = vlSymsp->TOP__v.Reg_ID[0x12];
    vlTOPp->Reg_ID[0x11] = vlSymsp->TOP__v.Reg_ID[0x11];
    vlTOPp->Reg_ID[0x10] = vlSymsp->TOP__v.Reg_ID[0x10];
    vlTOPp->Reg_ID[0xf] = vlSymsp->TOP__v.Reg_ID[0xf];
    vlTOPp->Reg_ID[0xe] = vlSymsp->TOP__v.Reg_ID[0xe];
    vlTOPp->Reg_ID[0xd] = vlSymsp->TOP__v.Reg_ID[0xd];
    vlTOPp->Reg_ID[0xc] = vlSymsp->TOP__v.Reg_ID[0xc];
    vlTOPp->Reg_ID[0xb] = vlSymsp->TOP__v.Reg_ID[0xb];
    vlTOPp->Reg_ID[0xa] = vlSymsp->TOP__v.Reg_ID[0xa];
    vlTOPp->Reg_ID[9] = vlSymsp->TOP__v.Reg_ID[9];
    vlTOPp->Reg_ID[8] = vlSymsp->TOP__v.Reg_ID[8];
    vlTOPp->Reg_ID[7] = vlSymsp->TOP__v.Reg_ID[7];
    vlTOPp->Reg_ID[6] = vlSymsp->TOP__v.Reg_ID[6];
    vlTOPp->Reg_ID[5] = vlSymsp->TOP__v.Reg_ID[5];
    vlTOPp->Reg_ID[4] = vlSymsp->TOP__v.Reg_ID[4];
    vlTOPp->Reg_ID[3] = vlSymsp->TOP__v.Reg_ID[3];
    vlTOPp->Reg_ID[2] = vlSymsp->TOP__v.Reg_ID[2];
    vlTOPp->Reg_ID[1] = vlSymsp->TOP__v.Reg_ID[1];
    vlTOPp->Reg_ID[0] = vlSymsp->TOP__v.Reg_ID[0];
}

void VMIPS::_sequent__TOP__5(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_sequent__TOP__5\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->MemRead = vlSymsp->TOP__v.__PVT__MemRead1_EXE;
    vlTOPp->MemWrite = vlSymsp->TOP__v.__PVT__MemWrite1_EXE;
    vlTOPp->data_address_2DM = vlSymsp->TOP__v.__PVT__aluResult1_MEM;
}

void VMIPS::_settle__TOP__7(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_settle__TOP__7\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->data_write_2DM = vlSymsp->TOP__v.data_write_2DM;
}

void VMIPS::_eval(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_eval\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if ((((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK))) 
	 | ((~ (IData)(vlTOPp->RESET)) & (IData)(vlTOPp->__Vclklast__TOP__RESET)))) {
	vlSymsp->TOP__v._sequent__TOP__v__1(vlSymsp);
	vlTOPp->_sequent__TOP__2(vlSymsp);
    }
    if (((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK)))) {
	vlSymsp->TOP__v._sequent__TOP__v__2(vlSymsp);
	vlTOPp->_sequent__TOP__3(vlSymsp);
    }
    if ((((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK))) 
	 | ((IData)(vlTOPp->RESET) & (~ (IData)(vlTOPp->__Vclklast__TOP__RESET))))) {
	vlSymsp->TOP__v._sequent__TOP__v__3(vlSymsp);
    }
    if ((((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK))) 
	 | ((~ (IData)(vlTOPp->RESET)) & (IData)(vlTOPp->__Vclklast__TOP__RESET)))) {
	vlSymsp->TOP__v._sequent__TOP__v__4(vlSymsp);
	vlTOPp->_sequent__TOP__5(vlSymsp);
    }
    if ((((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK))) 
	 | ((IData)(vlTOPp->RESET) & (~ (IData)(vlTOPp->__Vclklast__TOP__RESET))))) {
	vlSymsp->TOP__v._sequent__TOP__v__6(vlSymsp);
    }
    if ((((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK))) 
	 | ((~ (IData)(vlTOPp->RESET)) & (IData)(vlTOPp->__Vclklast__TOP__RESET)))) {
	vlSymsp->TOP__v._sequent__TOP__v__7(vlSymsp);
    }
    if ((((IData)(vlTOPp->CLK) & (~ (IData)(vlTOPp->__Vclklast__TOP__CLK))) 
	 | ((IData)(vlTOPp->RESET) ^ (IData)(vlTOPp->__Vclklast__TOP__RESET)))) {
	vlSymsp->TOP__v._multiclk__TOP__v__8(vlSymsp);
	vlSymsp->TOP__v._multiclk__TOP__v__10(vlSymsp);
	vlTOPp->_settle__TOP__7(vlSymsp);
    }
    vlSymsp->TOP__v._combo__TOP__v__11(vlSymsp);
    // Final
    vlTOPp->__Vclklast__TOP__CLK = vlTOPp->CLK;
    vlTOPp->__Vclklast__TOP__RESET = vlTOPp->RESET;
}

void VMIPS::_eval_initial(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_eval_initial\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlSymsp->TOP__v._initial__TOP__v(vlSymsp);
}

void VMIPS::final() {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::final\n"); );
    // Variables
    VMIPS__Syms* __restrict vlSymsp = this->__VlSymsp;
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
}

void VMIPS::_eval_settle(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_eval_settle\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_settle__TOP__1(vlSymsp);
    vlTOPp->_settle__TOP__4(vlSymsp);
    vlTOPp->_sequent__TOP__5(vlSymsp);
    vlSymsp->TOP__v._settle__TOP__v__5(vlSymsp);
    vlSymsp->TOP__v._settle__TOP__v__9(vlSymsp);
    vlTOPp->_settle__TOP__7(vlSymsp);
}

IData VMIPS::_change_request(VMIPS__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_PRINTF("    VMIPS::_change_request\n"); );
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // Change detection
    IData __req = false;  // Logically a bool
    return __req;
}
