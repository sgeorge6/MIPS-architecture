// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See VMIPS.h for the primary calling header

#ifndef _VMIPS_MIPS_H_
#define _VMIPS_MIPS_H_

#include "verilated.h"
class VMIPS__Syms;

//----------

VL_MODULE(VMIPS_MIPS) {
  public:
    // CELLS
    
    // PORTS
    VL_IN8(CLK,0,0);
    VL_IN8(RESET,0,0);
    VL_OUT8(MemRead,0,0);
    VL_OUT8(MemWrite,0,0);
    VL_OUT8(iBlkRead,0,0);
    VL_OUT8(iBlkWrite,0,0);
    VL_OUT8(dBlkRead,0,0);
    VL_OUT8(dBlkWrite,0,0);
    VL_OUT(R2_output,31,0);
    VL_OUT(data_address_2DM,31,0);
    VL_OUT(data_write_2DM,31,0);
    //char	__VpadToAlign20[4];
    VL_OUTW(block_write_2DM,255,0,8);
    VL_OUTW(block_write_2IM,255,0,8);
    VL_IN(PC_init,31,0);
    VL_IN(R2_input,31,0);
    VL_IN(data_read_fDM,31,0);
    //char	__VpadToAlign100[4];
    VL_INW(block_read_fDM,255,0,8);
    VL_INW(block_read_fIM,255,0,8);
    VL_IN(Instr1_fIM,31,0);
    VL_IN(Instr2_fIM,31,0);
    VL_OUT(Reg_ID[32],31,0);
    
    // LOCAL SIGNALS
    VL_SIG8(no_fetch,0,0);
    VL_SIG8(SYS,0,0);
    VL_SIG8(single_fetch_IDIF,0,0);
    VL_SIG8(__PVT__ALUSrc1_ID,0,0);
    VL_SIG8(comment1,0,0);
    VL_SIG8(__PVT__ALU_control1_ID,5,0);
    VL_SIG8(__PVT__ALU_control1_EXE,5,0);
    VL_SIG8(__PVT__writeRegister1_ID,4,0);
    VL_SIG8(__PVT__writeRegister1_MEM,4,0);
    VL_SIG8(__PVT__writeRegister1_WB,4,0);
    VL_SIG8(__PVT__writeRegister1_DST,4,0);
    VL_SIG8(__PVT__readRegisterA1_ID,4,0);
    VL_SIG8(__PVT__readRegisterB1_ID,4,0);
    VL_SIG8(__PVT__readRegisterB1_EXE,4,0);
    VL_SIG8(__PVT__Instr1_10_6_ID,4,0);
    VL_SIG8(__PVT__jumpRegister,4,0);
    VL_SIG8(__PVT__jumpR,0,0);
    VL_SIG8(FREEZE,0,0);
    VL_SIG8(__PVT__do_writeback1_EXE,0,0);
    VL_SIG8(__PVT__do_writeback1_MEM,0,0);
    VL_SIG8(__PVT__do_writeback1_WB,0,0);
    VL_SIG8(__PVT__do_writeback1_DST,0,0);
    VL_SIG8(__PVT__taken_branch1_ID,0,0);
    VL_SIG8(__PVT__MemRead1_ID,0,0);
    VL_SIG8(__PVT__MemRead1_EXE,0,0);
    VL_SIG8(__PVT__MemWrite1_ID,0,0);
    VL_SIG8(__PVT__MemWrite1_EXE,0,0);
    VL_SIG8(__PVT__no_new_fetch,0,0);
    VL_SIG8(__PVT__MemtoReg1_EXE,0,0);
    VL_SIG8(__PVT__MemtoReg1_ID,0,0);
    VL_SIG8(__PVT__MemtoReg1_MEM,0,0);
    VL_SIG8(__PVT__ID1__DOT__ALU_control1,5,0);
    VL_SIG8(__PVT__ID1__DOT__opcode1,5,0);
    VL_SIG8(__PVT__ID1__DOT__funct1,5,0);
    VL_SIG8(__PVT__ID1__DOT__format1,4,0);
    VL_SIG8(__PVT__ID1__DOT__rt1,4,0);
    VL_SIG8(__PVT__ID1__DOT__writeRegister1,4,0);
    VL_SIG8(__PVT__ID1__DOT__syscal_stop,0,0);
    VL_SIG8(__PVT__ID1__DOT__link1,0,0);
    VL_SIG8(__PVT__ID1__DOT__RegDst1,0,0);
    VL_SIG8(__PVT__ID1__DOT__jump1,0,0);
    VL_SIG8(__PVT__ID1__DOT__branch1,0,0);
    VL_SIG8(__PVT__ID1__DOT__MemRead1,0,0);
    VL_SIG8(__PVT__ID1__DOT__MemtoReg1,0,0);
    VL_SIG8(__PVT__ID1__DOT__MemWrite1,0,0);
    VL_SIG8(__PVT__ID1__DOT__ALUSrc1,0,0);
    VL_SIG8(__PVT__ID1__DOT__RegWrite1,0,0);
    VL_SIG8(__PVT__ID1__DOT__jumpRegister_Flag1,0,0);
    VL_SIG8(__PVT__ID1__DOT__sign_or_zero_Flag1,0,0);
    VL_SIG8(__PVT__ID1__DOT__syscal1,0,0);
    VL_SIG8(__PVT__ID1__DOT__syscalBubbleCounter,1,0);
    VL_SIG8(__PVT__EXE1__DOT__OpRegisterB1,4,0);
    VL_SIG8(__PVT__EXE1__DOT__ALU1__DOT__i,4,0);
    //char	__VpadToAlign361[3];
    VL_SIG(Instr_read_fIC,31,0);
    VL_SIG(R2_output_ID,31,0);
    VL_SIG(Instr_fMEM,31,0);
    VL_SIG(Instr_address_2IM,31,0);
    VL_SIG(CIA_IFID,31,0);
    VL_SIG(PCA_IFID,31,0);
    VL_SIG(nextInstruction_address_IDIF,31,0);
    VL_SIG(__PVT__OpA,31,0);
    VL_SIG(__PVT__OpB,31,0);
    VL_SIG(__PVT__tempInstruction_address,31,0);
    VL_SIG(__PVT__Instr1_IF,31,0);
    VL_SIG(__PVT__Instr1_ID,31,0);
    VL_SIG(__PVT__Instr1_EXE,31,0);
    VL_SIG(__PVT__aluResult1_MEM,31,0);
    VL_SIG(__PVT__aluResult1_WB,31,0);
    VL_SIG(__PVT__readDataB1_ID,31,0);
    VL_SIG(__PVT__readDataB1_EXE,31,0);
    VL_SIG(__PVT__MemData1,31,0);
    VL_SIG(__PVT__writeData1_WB,31,0);
    VL_SIG(__PVT__writeData1_DST,31,0);
    VL_SIG(Instr1_IFID,31,0);
    VL_SIG(Instr2_IFID,31,0);
    VL_SIG(__PVT__IF1__DOT__PC,31,0);
    VL_SIG(__PVT__ID1__DOT__com_OpA1,31,0);
    VL_SIG(__PVT__ID1__DOT__com_OpB1,31,0);
    VL_SIG(__PVT__ID1__DOT__signExtended_output1,31,0);
    VL_SIG(__PVT__ID1__DOT__readDataA1,31,0);
    VL_SIG(__PVT__ID1__DOT__readDataB1,31,0);
    VL_SIG(__PVT__EXE1__DOT__aluResult1,31,0);
    VL_SIG(__PVT__EXE1__DOT__OpA1,31,0);
    VL_SIG(__PVT__EXE1__DOT__OpB1,31,0);
    VL_SIG(__PVT__EXE1__DOT__HI,31,0);
    VL_SIG(__PVT__EXE1__DOT__LO,31,0);
    VL_SIG(__PVT__MEM1__DOT__data_read_aligned,31,0);
    //char	__VpadToAlign500[4];
    VL_SIG64(__PVT__EXE1__DOT__ALU1__DOT__temp,63,0);
    
    // LOCAL VARIABLES
    VL_SIG8(__Vdly__ID1__DOT__syscalBubbleCounter,1,0);
    VL_SIG8(__Vdly__writeRegister1_ID,4,0);
    VL_SIG8(__Vdly__do_writeback1_EXE,0,0);
    VL_SIG8(__Vdly__MemRead1_EXE,0,0);
    VL_SIG8(__Vdly__writeRegister1_MEM,4,0);
    VL_SIG8(__Vdly__do_writeback1_MEM,0,0);
    VL_SIG8(__Vdly__readRegisterB1_EXE,4,0);
    VL_SIG8(__Vdlyvdim0__Reg_ID__v1,4,0);
    VL_SIG8(__Vdlyvset__Reg_ID__v1,0,0);
    VL_SIG8(__Vdly__MemtoReg1_MEM,0,0);
    VL_SIG8(__Vdly__writeRegister1_WB,4,0);
    VL_SIG8(__Vdly__do_writeback1_WB,0,0);
    VL_SIG(__Vdly__tempInstruction_address,31,0);
    VL_SIG(__Vdly__aluResult1_MEM,31,0);
    VL_SIG(__Vdlyvval__Reg_ID__v1,31,0);
    VL_SIG(__Vdly__aluResult1_WB,31,0);
    VL_SIG(__Vdly__MemData1,31,0);
    
    // INTERNAL VARIABLES
  private:
    VMIPS__Syms*	__VlSymsp;		// Symbol table
  public:
    
    // PARAMETERS
    
    // CONSTRUCTORS
  private:
    VMIPS_MIPS& operator= (const VMIPS_MIPS&);	///< Copying not allowed
    VMIPS_MIPS(const VMIPS_MIPS&);	///< Copying not allowed
  public:
    VMIPS_MIPS(const char* name="TOP");
    ~VMIPS_MIPS();
    
    // USER METHODS
    
    // API METHODS
    
    // INTERNAL METHODS
    void __Vconfigure(VMIPS__Syms* symsp, bool first);
    static void	_combo__TOP__v__11(VMIPS__Syms* __restrict vlSymsp);
    static void	_initial__TOP__v(VMIPS__Syms* __restrict vlSymsp);
    static void	_multiclk__TOP__v__10(VMIPS__Syms* __restrict vlSymsp);
    static void	_multiclk__TOP__v__8(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__1(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__2(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__3(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__4(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__6(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__7(VMIPS__Syms* __restrict vlSymsp);
    static void	_settle__TOP__v__5(VMIPS__Syms* __restrict vlSymsp);
    static void	_settle__TOP__v__9(VMIPS__Syms* __restrict vlSymsp);
} VL_ATTR_ALIGNED(128);

#endif  /*guard*/
