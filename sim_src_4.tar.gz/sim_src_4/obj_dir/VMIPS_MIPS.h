// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See VMIPS.h for the primary calling header

#ifndef _VMIPS_MIPS_H_
#define _VMIPS_MIPS_H_

#include "verilated.h"
#include "VMIPS__Inlines.h"
class VMIPS__Syms;
class VerilatedVcd;

//----------

VL_MODULE(VMIPS_MIPS) {
  public:
    // CELLS
    
    // PORTS
    VL_IN8(CLK,0,0);
    VL_IN8(RESET,0,0);
    VL_OUT8(MemRead,0,0);
    VL_OUT8(MemWrite,0,0);
    VL_OUT8(dBlkRead,0,0);
    VL_OUT8(dBlkWrite,0,0);
    VL_OUT8(iBlkRead,0,0);
    VL_OUT8(iBlkWrite,0,0);
    VL_OUT(R2_output,31,0);
    VL_OUT(data_address_2DM,31,0);
    VL_OUT(data_write_2DM,31,0);
    //char	__VpadToAlign20[4];
    VL_OUTW(block_write_2DM,255,0,8);
    VL_OUTW(block_write1_2IM,255,0,8);
    VL_OUTW(block_write2_2IM,255,0,8);
    VL_IN(PC_init,31,0);
    VL_IN(R2_input,31,0);
    VL_INW(block_read_fDM,255,0,8);
    VL_INW(block_read1_fIM,255,0,8);
    VL_INW(block_read2_fIM,255,0,8);
    
    // LOCAL SIGNALS
    VL_SIG8(no_fetch,0,0);
    VL_SIG8(SYS,0,0);
    VL_SIG8(single_fetch_IDIF,0,0);
    VL_SIG8(ALU_control1_IDEXE,5,0);
    VL_SIG8(ALU_control2_IDEXE,5,0);
    VL_SIG8(ALU_control1_EXEM,5,0);
    VL_SIG8(ALU_control2_EXEM,5,0);
    VL_SIG8(writeRegister1_IDEXE,4,0);
    VL_SIG8(writeRegister2_IDEXE,4,0);
    VL_SIG8(writeRegister1_EXEM,4,0);
    VL_SIG8(writeRegister2_EXEM,4,0);
    VL_SIG8(writeRegister1_MEMW,4,0);
    VL_SIG8(writeRegister2_MEMW,4,0);
    VL_SIG8(writeRegister1_WBID,4,0);
    VL_SIG8(writeRegister2_WBID,4,0);
    VL_SIG8(writeRegister1_WBEXE,4,0);
    VL_SIG8(writeRegister2_WBEXE,4,0);
    VL_SIG8(Instr1_10_6_IDEXE,4,0);
    VL_SIG8(Instr2_10_6_IDEXE,4,0);
    VL_SIG8(readRegisterA2_IDEXE,4,0);
    VL_SIG8(readRegisterA1_IDEXE,4,0);
    VL_SIG8(readRegisterB1_IDEXE,4,0);
    VL_SIG8(readRegisterB2_IDEXE,4,0);
    VL_SIG8(MemtoReg1_IDEXE,0,0);
    VL_SIG8(MemtoReg2_IDEXE,0,0);
    VL_SIG8(MemtoReg1_EXEM,0,0);
    VL_SIG8(MemtoReg2_EXEM,0,0);
    VL_SIG8(MemtoReg1_MEMW,0,0);
    VL_SIG8(MemtoReg2_MEMW,0,0);
    VL_SIG8(MemRead1_IDEXE,0,0);
    VL_SIG8(MemRead2_IDEXE,0,0);
    VL_SIG8(MemRead1_EXEM,0,0);
    VL_SIG8(MemRead2_EXEM,0,0);
    VL_SIG8(MemWrite1_IDEXE,0,0);
    VL_SIG8(MemWrite2_IDEXE,0,0);
    VL_SIG8(MemWrite1_EXEM,0,0);
    VL_SIG8(MemWrite2_EXEM,0,0);
    VL_SIG8(do_writeback1_WBID,0,0);
    VL_SIG8(do_writeback2_WBID,0,0);
    VL_SIG8(do_writeback1_IDEXE,0,0);
    VL_SIG8(do_writeback2_IDEXE,0,0);
    VL_SIG8(do_writeback1_MEMW,0,0);
    VL_SIG8(do_writeback2_MEMW,0,0);
    VL_SIG8(do_writeback1_EXEM,0,0);
    VL_SIG8(do_writeback2_EXEM,0,0);
    VL_SIG8(do_writeback1_WBEXE,0,0);
    VL_SIG8(do_writeback2_WBEXE,0,0);
    VL_SIG8(taken_branch1_IDIF,0,0);
    VL_SIG8(taken_branch2_IDIF,0,0);
    VL_SIG8(fetchNull1_fID,0,0);
    VL_SIG8(fetchNull2_fID,0,0);
    VL_SIG8(ALUSrc1_IDEXE,0,0);
    VL_SIG8(ALUSrc2_IDEXE,0,0);
    VL_SIG8(ALUSrc1_EXEM,0,0);
    VL_SIG8(ALUSrc2_EXEM,0,0);
    VL_SIG8(FREEZE,0,0);
    VL_SIG8(MVECT,1,0);
    VL_SIG8(__PVT__DataWriteMode,1,0);
    VL_SIG8(__PVT__IMISS,0,0);
    VL_SIG8(__PVT__DMISS,0,0);
    VL_SIG8(__PVT__nextInstruction_address_IDIF1,0,0);
    VL_SIG8(__PVT__nextInstruction_address_IDIF2,0,0);
    VL_SIG8(__PVT__FullFlush,0,0);
    VL_SIG8(__PVT__decode_stall,0,0);
    VL_SIG8(__PVT__rq_out1,0,0);
    VL_SIG8(__PVT__BrJpFlg,0,0);
    VL_SIG8(__PVT__iCache1__DOT__hit1,0,0);
    VL_SIG8(__PVT__iCache1__DOT__hit2,0,0);
    VL_SIG8(__PVT__iCache1__DOT__bread0,0,0);
    VL_SIG8(__PVT__iCache1__DOT__waitCount,3,0);
    VL_SIG8(__PVT__dCache1__DOT__hit0,0,0);
    VL_SIG8(__PVT__dCache1__DOT__hit1,0,0);
    VL_SIG8(__PVT__dCache1__DOT__bread0,0,0);
    VL_SIG8(__PVT__dCache1__DOT__bread1,0,0);
    VL_SIG8(__PVT__dCache1__DOT__waitCount,3,0);
    VL_SIG8(__PVT__ID1__DOT__rd_en1,0,0);
    VL_SIG8(__PVT__ID1__DOT__rd_en2,0,0);
    VL_SIG8(__PVT__ID1__DOT__Instr_droped_flg,0,0);
    VL_SIG8(__PVT__ID1__DOT__UseImm1,0,0);
    VL_SIG8(__PVT__ID1__DOT__UseImm2,0,0);
    VL_SIG8(__PVT__ID1__DOT__SrcA1,5,0);
    VL_SIG8(__PVT__ID1__DOT__SrcA2,5,0);
    VL_SIG8(__PVT__ID1__DOT__SrcB1,5,0);
    VL_SIG8(__PVT__ID1__DOT__SrcB2,5,0);
    VL_SIG8(__PVT__ID1__DOT__Dst1,5,0);
    VL_SIG8(__PVT__ID1__DOT__Dst2,5,0);
    VL_SIG8(__PVT__ID1__DOT__Opcode1,7,0);
    VL_SIG8(__PVT__ID1__DOT__Opcode2,7,0);
    VL_SIG8(__PVT__ID1__DOT__MemFlg1,0,0);
    VL_SIG8(__PVT__ID1__DOT__MemFlg2,0,0);
    VL_SIG8(__PVT__ID1__DOT__MulDivFlg1,0,0);
    VL_SIG8(__PVT__ID1__DOT__MulDivFlg2,0,0);
    VL_SIG8(__PVT__ID1__DOT__BrJpFlg1,0,0);
    VL_SIG8(__PVT__ID1__DOT__BrJpFlg2,0,0);
    VL_SIG8(__PVT__ID1__DOT__unConJpFlg1,0,0);
    VL_SIG8(__PVT__ID1__DOT__unConJpFlg2,0,0);
    VL_SIG8(__PVT__ID1__DOT__AluFlg1,0,0);
    VL_SIG8(__PVT__ID1__DOT__AluFlg2,0,0);
    VL_SIG8(__PVT__ID1__DOT__SysCallFlg1,0,0);
    VL_SIG8(__PVT__ID1__DOT__SysCallFlg2,0,0);
    VL_SIG8(__PVT__ID1__DOT__queueSel1,1,0);
    VL_SIG8(__PVT__ID1__DOT__queueSel2,1,0);
    VL_SIG8(__PVT__ID1__DOT__wr_en1,0,0);
    VL_SIG8(__PVT__ID1__DOT__wr_en2,0,0);
    VL_SIG8(__PVT__ID1__DOT__wr_en1_rename,0,0);
    VL_SIG8(__PVT__ID1__DOT__wr_en2_rename,0,0);
    VL_SIG8(__PVT__ID1__DOT__rd_en1_rename,0,0);
    VL_SIG8(__PVT__ID1__DOT__rd_en2_rename,0,0);
    VL_SIG8(__PVT__ID1__DOT__Rename_Queue__DOT__wr_p,2,0);
    VL_SIG8(__PVT__ID1__DOT__Rename_Queue__DOT__rd_p,2,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__link1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__RegDst1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__jump1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__branch1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__MemRead1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__MemWrite1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__RegWrite1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__jumpRegister_Flag1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__sign_or_zero_Flag1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__ALU_control1,5,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__predTaken_branch1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__opcode1,5,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__format1,4,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__rt1,3,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__funct1,5,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__taken_branch1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__comment1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__comment2,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__comment3,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder1__DOT__MemtoReg1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__link1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__RegDst1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__jump1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__branch1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__MemRead1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__MemWrite1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__RegWrite1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__jumpRegister_Flag1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__sign_or_zero_Flag1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__ALU_control1,5,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__predTaken_branch1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__opcode1,5,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__format1,4,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__rt1,3,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__funct1,5,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__taken_branch1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__comment1,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__comment2,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__comment3,0,0);
    VL_SIG8(__PVT__ID1__DOT__decoder2__DOT__MemtoReg1,0,0);
    //char	__VpadToAlign378[2];
    VL_SIG(R2_output_ID,31,0);
    VL_SIG(Instr_fMEM,31,0);
    VL_SIG(Instr_address1_2IM,31,0);
    VL_SIG(__PVT__Instr_address2_2IM,31,0);
    VL_SIG(CIA_IFID,31,0);
    VL_SIG(CIB_IFID,31,0);
    VL_SIG(PCA_IFID,31,0);
    VL_SIG(PCB_IFID,31,0);
    VL_SIG(nextInstruction_address1_IDIF,31,0);
    VL_SIG(__PVT__nextInstruction_address2_IDIF,31,0);
    VL_SIG(writeData1_WBID,31,0);
    VL_SIG(writeData2_WBID,31,0);
    VL_SIG(writeData1_WBEXE,31,0);
    VL_SIG(writeData2_WBEXE,31,0);
    VL_SIG(writeData1_MID,31,0);
    VL_SIG(writeData2_MID,31,0);
    VL_SIG(Dest_Value1_IDEXE,31,0);
    VL_SIG(Dest_Value2_IDEXE,31,0);
    VL_SIG(Dest_Value1_EXEM,31,0);
    VL_SIG(Dest_Value2_EXEM,31,0);
    VL_SIG(Instr1_IDEXE,31,0);
    VL_SIG(Instr2_IDEXE,31,0);
    VL_SIG(Instr1_EXEM,31,0);
    VL_SIG(Instr2_EXEM,31,0);
    VL_SIG(Instr1_IFID,31,0);
    VL_SIG(Instr2_IFID,31,0);
    VL_SIG(Operand_A1_IDEXE,31,0);
    VL_SIG(Operand_A2_IDEXE,31,0);
    VL_SIG(Operand_B1_IDEXE,31,0);
    VL_SIG(Operand_B2_IDEXE,31,0);
    VL_SIG(aluResult1_EXEM,31,0);
    VL_SIG(aluResult2_EXEM,31,0);
    VL_SIG(aluResult1_EXEID,31,0);
    VL_SIG(aluResult2_EXEID,31,0);
    VL_SIG(aluResult1_MEMW,31,0);
    VL_SIG(aluResult2_MEMW,31,0);
    VL_SIG(aluResult1_WBID,31,0);
    VL_SIG(aluResult2_WBID,31,0);
    VL_SIG(data_read1_MEMW,31,0);
    VL_SIG(data_read2_MEMW,31,0);
    VL_SIG(readDataB1_IDEXE,31,0);
    VL_SIG(readDataB2_IDEXE,31,0);
    VL_SIG(readDataB1_EXEM,31,0);
    VL_SIG(readDataB2_EXEM,31,0);
    VL_SIG(Instr1_fIC,31,0);
    VL_SIG(Instr2_fIC,31,0);
    VL_SIG(__PVT__n,31,0);
    VL_SIGW(__PVT__iCache1__DOT__cc0__DOT__valid,1023,0,32);
    VL_SIGW(__PVT__iCache1__DOT__cc0__DOT__dirty,1023,0,32);
    VL_SIGW(__PVT__dCache1__DOT__block_out0,255,0,8);
    VL_SIGW(__PVT__dCache1__DOT__block_out1,255,0,8);
    VL_SIGW(__PVT__dCache1__DOT__policy,256,0,9);
    //char	__VpadToAlign924[4];
    VL_SIGW(__PVT__dCache1__DOT__cc0__DOT__valid,511,0,16);
    VL_SIGW(__PVT__dCache1__DOT__cc0__DOT__dirty,511,0,16);
    VL_SIGW(__PVT__dCache1__DOT__cc1__DOT__valid,511,0,16);
    VL_SIGW(__PVT__dCache1__DOT__cc1__DOT__dirty,511,0,16);
    VL_SIG(__PVT__IF1__DOT__PC,31,0);
    VL_SIG(__PVT__IF1__DOT__FPC,31,0);
    VL_SIG(__PVT__ID1__DOT__Instr_droped,31,0);
    VL_SIG(__PVT__ID1__DOT__Instr_addr_droped,31,0);
    VL_SIG(__PVT__ID1__DOT__Instr_decoder_in1,31,0);
    VL_SIG(__PVT__ID1__DOT__Instr_decoder_in2,31,0);
    VL_SIG(__PVT__ID1__DOT__Instr_addr_decoder_in1,31,0);
    VL_SIG(__PVT__ID1__DOT__Instr_addr_decoder_in2,31,0);
    VL_SIG(__PVT__ID1__DOT__dec_q__DOT__remain_cnt,31,0);
    VL_SIG(__PVT__ID1__DOT__dec_q__DOT__wr_p,31,0);
    VL_SIG(__PVT__ID1__DOT__dec_q__DOT__rd_p,31,0);
    VL_SIG(__PVT__ID1__DOT__Rename_Queue__DOT__remain_cnt,31,0);
    VL_SIG(__PVT__ID1__DOT__decoder1__DOT__signExtended_output1,31,0);
    VL_SIG(__PVT__ID1__DOT__decoder2__DOT__signExtended_output1,31,0);
    VL_SIG64(__PVT__ID1__DOT__data_in2,63,0);
    VL_SIG64(__PVT__ID1__DOT__data_out1,63,0);
    VL_SIG64(__PVT__ID1__DOT__data_out2,63,0);
    VL_SIG(Reg_ID[32],31,0);
    VL_SIG(__PVT__iCache1__DOT__cc0__DOT__tags[1024],16,0);
    VL_SIGW(__PVT__iCache1__DOT__cc0__DOT__blocks[1024],255,0,8);
    VL_SIG(__PVT__dCache1__DOT__cc0__DOT__tags[512],17,0);
    VL_SIGW(__PVT__dCache1__DOT__cc0__DOT__blocks[512],255,0,8);
    VL_SIG(__PVT__dCache1__DOT__cc1__DOT__tags[512],17,0);
    VL_SIGW(__PVT__dCache1__DOT__cc1__DOT__blocks[512],255,0,8);
    VL_SIG64(__PVT__ID1__DOT__dec_q__DOT__ram[1],63,0);
    VL_SIG(__PVT__ID1__DOT__Rename_Queue__DOT__ram[9],31,0);
    
    // LOCAL VARIABLES
    VL_SIG8(dCache1__DOT____Vlvbound1,0,0);
    VL_SIG8(__Vdly__iCache1__DOT__waitCount,3,0);
    VL_SIG8(__Vdly__dCache1__DOT__waitCount,3,0);
    //char	__VpadToAlign75171[1];
    VL_SIG(ID1__DOT____Vcellout__Rename_Queue____pinNumber11,31,0);
    VL_SIG(ID1__DOT____Vcellout__Rename_Queue____pinNumber10,31,0);
    VL_SIG(ID1__DOT__Rename_Queue__DOT____Vlvbound1,31,0);
    VL_SIG(ID1__DOT__Rename_Queue__DOT____Vlvbound2,31,0);
    VL_SIG(ID1__DOT__Rename_Queue__DOT____Vlvbound3,31,0);
    VL_SIG(__Vdly__IF1__DOT__PC,31,0);
    VL_SIG(__Vdly__IF1__DOT__FPC,31,0);
    VL_SIG64(ID1__DOT__dec_q__DOT____Vlvbound1,63,0);
    VL_SIG64(ID1__DOT__dec_q__DOT____Vlvbound2,63,0);
    VL_SIG64(ID1__DOT__dec_q__DOT____Vlvbound3,63,0);
    
    // INTERNAL VARIABLES
  private:
    //char	__VpadToAlign75228[4];
    VMIPS__Syms*	__VlSymsp;		// Symbol table
  public:
    
    // PARAMETERS
    
    // CONSTRUCTORS
  private:
    VMIPS_MIPS& operator= (const VMIPS_MIPS&);	///< Copying not allowed
    VMIPS_MIPS(const VMIPS_MIPS&);	///< Copying not allowed
  public:
    VMIPS_MIPS(const char* name="TOP");
    ~VMIPS_MIPS();
    void trace (VerilatedVcdC* tfp, int levels, int options=0);
    
    // USER METHODS
    
    // API METHODS
    
    // INTERNAL METHODS
    void __Vconfigure(VMIPS__Syms* symsp, bool first);
    static void	_combo__TOP__v__11(VMIPS__Syms* __restrict vlSymsp);
    static void	_combo__TOP__v__13(VMIPS__Syms* __restrict vlSymsp);
    static void	_combo__TOP__v__15(VMIPS__Syms* __restrict vlSymsp);
    static void	_combo__TOP__v__9(VMIPS__Syms* __restrict vlSymsp);
    static void	_initial__TOP__v(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__2(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__3(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__5(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__6(VMIPS__Syms* __restrict vlSymsp);
    static void	_sequent__TOP__v__8(VMIPS__Syms* __restrict vlSymsp);
    static void	_settle__TOP__v__1(VMIPS__Syms* __restrict vlSymsp);
    static void	_settle__TOP__v__10(VMIPS__Syms* __restrict vlSymsp);
    static void	_settle__TOP__v__12(VMIPS__Syms* __restrict vlSymsp);
    static void	_settle__TOP__v__14(VMIPS__Syms* __restrict vlSymsp);
    static void	_settle__TOP__v__4(VMIPS__Syms* __restrict vlSymsp);
    static void	_settle__TOP__v__7(VMIPS__Syms* __restrict vlSymsp);
    static void traceInit (VerilatedVcd* vcdp, void* userthis, uint32_t code);
    static void traceFull (VerilatedVcd* vcdp, void* userthis, uint32_t code);
    static void traceChg  (VerilatedVcd* vcdp, void* userthis, uint32_t code);
} VL_ATTR_ALIGNED(128);

#endif  /*guard*/
