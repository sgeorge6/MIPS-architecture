// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "VMIPS__Syms.h"


//======================

void VMIPS::traceChg(VerilatedVcd* vcdp, void* userthis, uint32_t code) {
    // Callback from vcd->dump()
    VMIPS* t=(VMIPS*)userthis;
    VMIPS__Syms* __restrict vlSymsp = t->__VlSymsp; // Setup global symbol table
    if (vlSymsp->getClearActivity()) {
	t->traceChgThis (vlSymsp, vcdp, code);
    }
}

//======================


void VMIPS::traceChgThis(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	if (VL_UNLIKELY((1 & vlTOPp->__Vm_traceActivity))) {
	    vlTOPp->traceChgThis__2(vlSymsp, vcdp, code);
	}
	if (VL_UNLIKELY((1 & (vlTOPp->__Vm_traceActivity 
			      | (vlTOPp->__Vm_traceActivity 
				 >> 1))))) {
	    vlTOPp->traceChgThis__3(vlSymsp, vcdp, code);
	}
	if (VL_UNLIKELY((1 & (vlTOPp->__Vm_traceActivity 
			      | (vlTOPp->__Vm_traceActivity 
				 >> 2))))) {
	    vlTOPp->traceChgThis__4(vlSymsp, vcdp, code);
	}
	if (VL_UNLIKELY((1 & ((vlTOPp->__Vm_traceActivity 
			       | (vlTOPp->__Vm_traceActivity 
				  >> 2)) | (vlTOPp->__Vm_traceActivity 
					    >> 4))))) {
	    vlTOPp->traceChgThis__5(vlSymsp, vcdp, code);
	}
	if (VL_UNLIKELY((1 & (vlTOPp->__Vm_traceActivity 
			      | (vlTOPp->__Vm_traceActivity 
				 >> 3))))) {
	    vlTOPp->traceChgThis__6(vlSymsp, vcdp, code);
	}
	if (VL_UNLIKELY((1 & (vlTOPp->__Vm_traceActivity 
			      | (vlTOPp->__Vm_traceActivity 
				 >> 4))))) {
	    vlTOPp->traceChgThis__7(vlSymsp, vcdp, code);
	}
	if (VL_UNLIKELY((2 & vlTOPp->__Vm_traceActivity))) {
	    vlTOPp->traceChgThis__8(vlSymsp, vcdp, code);
	}
	if (VL_UNLIKELY((4 & vlTOPp->__Vm_traceActivity))) {
	    vlTOPp->traceChgThis__9(vlSymsp, vcdp, code);
	}
	vlTOPp->traceChgThis__10(vlSymsp, vcdp, code);
    }
    // Final
    vlTOPp->__Vm_traceActivity = 0;
}

void VMIPS::traceChgThis__2(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->chgBus  (c+1,(vlSymsp->TOP__v.__PVT__DataWriteMode),2);
	vcdp->chgBit  (c+2,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__predTaken_branch1));
	vcdp->chgBit  (c+3,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__comment1));
	vcdp->chgBit  (c+4,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__comment2));
	vcdp->chgBit  (c+5,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__comment3));
	vcdp->chgBit  (c+6,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__predTaken_branch1));
	vcdp->chgBit  (c+7,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__comment1));
	vcdp->chgBit  (c+8,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__comment2));
	vcdp->chgBit  (c+9,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__comment3));
    }
}

void VMIPS::traceChgThis__3(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->chgBus  (c+10,(((IData)(vlSymsp->TOP__v.__PVT__dCache1__DOT__hit0)
			       ? ((0x10 & vlSymsp->TOP__v.data_address_2DM)
				   ? ((8 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((4 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[0]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[0])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[0]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[0]))
					   : ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[1]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[1])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[1]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[1])))
				       : ((4 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[2]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[2])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[2]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[2]))
					   : ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[3]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[3])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[3]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[3]))))
				   : ((8 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((4 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[4]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[4])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[4]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[4]))
					   : ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[5]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[5])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[5]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[5])))
				       : ((4 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[6]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[6])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[6]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[6]))
					   : ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[7]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[7])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[7]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[7])))))
			       : ((0x10 & vlSymsp->TOP__v.data_address_2DM)
				   ? ((8 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((4 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[0]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[0])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[0]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[0]))
					   : ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[1]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[1])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[1]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[1])))
				       : ((4 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[2]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[2])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[2]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[2]))
					   : ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[3]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[3])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[3]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[3]))))
				   : ((8 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((4 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[4]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[4])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[4]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[4]))
					   : ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[5]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[5])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[5]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[5])))
				       : ((4 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[6]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[6])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[6]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[6]))
					   : ((2 & vlSymsp->TOP__v.data_address_2DM)
					       ? ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[7]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[7])
					       : ((1 
						   & vlSymsp->TOP__v.data_address_2DM)
						   ? 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[7]
						   : 
						  vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[7]))))))),32);
	vcdp->chgBit  (c+11,(vlSymsp->TOP__v.__PVT__dCache1__DOT__hit0));
	vcdp->chgBit  (c+12,(vlSymsp->TOP__v.__PVT__dCache1__DOT__hit1));
	vcdp->chgBus  (c+13,(((0x10 & vlSymsp->TOP__v.data_address_2DM)
			       ? ((8 & vlSymsp->TOP__v.data_address_2DM)
				   ? ((4 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[0]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[0])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[0]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[0]))
				       : ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[1]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[1])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[1]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[1])))
				   : ((4 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[2]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[2])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[2]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[2]))
				       : ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[3]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[3])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[3]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[3]))))
			       : ((8 & vlSymsp->TOP__v.data_address_2DM)
				   ? ((4 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[4]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[4])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[4]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[4]))
				       : ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[5]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[5])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[5]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[5])))
				   : ((4 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[6]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[6])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[6]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[6]))
				       : ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[7]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[7])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[7]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0[7])))))),32);
	vcdp->chgBus  (c+14,(((0x10 & vlSymsp->TOP__v.data_address_2DM)
			       ? ((8 & vlSymsp->TOP__v.data_address_2DM)
				   ? ((4 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[0]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[0])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[0]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[0]))
				       : ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[1]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[1])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[1]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[1])))
				   : ((4 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[2]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[2])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[2]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[2]))
				       : ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[3]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[3])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[3]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[3]))))
			       : ((8 & vlSymsp->TOP__v.data_address_2DM)
				   ? ((4 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[4]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[4])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[4]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[4]))
				       : ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[5]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[5])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[5]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[5])))
				   : ((4 & vlSymsp->TOP__v.data_address_2DM)
				       ? ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[6]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[6])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[6]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[6]))
				       : ((2 & vlSymsp->TOP__v.data_address_2DM)
					   ? ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[7]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[7])
					   : ((1 & vlSymsp->TOP__v.data_address_2DM)
					       ? vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[7]
					       : vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1[7])))))),32);
	vcdp->chgArray(c+15,(vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out0),256);
	vcdp->chgArray(c+23,(vlSymsp->TOP__v.__PVT__dCache1__DOT__block_out1),256);
	vcdp->chgBit  (c+31,(vlSymsp->TOP__v.__PVT__ID1__DOT__rename_q_wr2));
    }
}

void VMIPS::traceChgThis__4(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->chgBus  (c+32,(vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_decoder_in1),32);
	vcdp->chgBus  (c+33,(vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_decoder_in2),32);
	vcdp->chgBus  (c+34,(vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in1),32);
	vcdp->chgBus  (c+35,(vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2),32);
    }
}

void VMIPS::traceChgThis__5(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Variables
    VL_SIGW(__Vtemp2,98,0,4);
    // Body
    {
	__Vtemp2[0] = (IData)((((QData)((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SysCallFlg2)) 
				<< 0x22) | (((QData)((IData)(
							     ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__jump1)
							       ? 
							      ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__jumpRegister_Flag1)
							        ? 
							       ((0xf0000000 
								 & vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2) 
								| (0xffffffc 
								   & (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_decoder_in2 
								      << 2)))
							        : vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)
							       : 
							      ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__taken_branch1)
							        ? 
							       ((IData)(4) 
								+ 
								(vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2 
								 + 
								 (vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1 
								  << 2)))
							        : 
							       ((IData)(4) 
								+ vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2))))) 
					     << 2) 
					    | (QData)((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__queueSel2)))));
	__Vtemp2[1] = ((0xfffffff8 & ((IData)((((QData)((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__UseImm2)) 
						<< 0x3f) 
					       | (((QData)((IData)(
								   ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__link1)
								     ? 
								    ((IData)(8) 
								     + vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)
								     : vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1))) 
						   << 0x1f) 
						  | (QData)((IData)(
								    (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcA2) 
								      << 0x19) 
								     | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcB2) 
									 << 0x13) 
									| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__Dst2) 
									    << 0xd) 
									   | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__Opcode2) 
									       << 5) 
									      | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__MemFlg2) 
										<< 4) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__MulDivFlg2) 
										<< 3) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__BrJpFlg2) 
										<< 2) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__unConJpFlg2) 
										<< 1) 
										| (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__AluFlg2)))))))))))))) 
				      << 3)) | (IData)(
						       ((((QData)((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SysCallFlg2)) 
							  << 0x22) 
							 | (((QData)((IData)(
									     ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__jump1)
									       ? 
									      ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__jumpRegister_Flag1)
									        ? 
									       ((0xf0000000 
										& vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2) 
										| (0xffffffc 
										& (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_decoder_in2 
										<< 2)))
									        : vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)
									       : 
									      ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__taken_branch1)
									        ? 
									       ((IData)(4) 
										+ 
										(vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2 
										+ 
										(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1 
										<< 2)))
									        : 
									       ((IData)(4) 
										+ vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2))))) 
							     << 2) 
							    | (QData)((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__queueSel2)))) 
							>> 0x20)));
	__Vtemp2[2] = ((7 & ((IData)((((QData)((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__UseImm2)) 
				       << 0x3f) | (
						   ((QData)((IData)(
								    ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__link1)
								      ? 
								     ((IData)(8) 
								      + vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)
								      : vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1))) 
						    << 0x1f) 
						   | (QData)((IData)(
								     (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcA2) 
								       << 0x19) 
								      | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcB2) 
									  << 0x13) 
									 | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__Dst2) 
									     << 0xd) 
									    | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__Opcode2) 
										<< 5) 
									       | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__MemFlg2) 
										<< 4) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__MulDivFlg2) 
										<< 3) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__BrJpFlg2) 
										<< 2) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__unConJpFlg2) 
										<< 1) 
										| (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__AluFlg2)))))))))))))) 
			     >> 0x1d)) | (0xfffffff8 
					  & ((IData)(
						     ((((QData)((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__UseImm2)) 
							<< 0x3f) 
						       | (((QData)((IData)(
									   ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__link1)
									     ? 
									    ((IData)(8) 
									     + vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)
									     : vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1))) 
							   << 0x1f) 
							  | (QData)((IData)(
									    (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcA2) 
									      << 0x19) 
									     | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcB2) 
										<< 0x13) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__Dst2) 
										<< 0xd) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__Opcode2) 
										<< 5) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__MemFlg2) 
										<< 4) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__MulDivFlg2) 
										<< 3) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__BrJpFlg2) 
										<< 2) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__unConJpFlg2) 
										<< 1) 
										| (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__AluFlg2))))))))))))) 
						      >> 0x20)) 
					     << 3)));
	__Vtemp2[3] = (7 & ((IData)(((((QData)((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__UseImm2)) 
				       << 0x3f) | (
						   ((QData)((IData)(
								    ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__link1)
								      ? 
								     ((IData)(8) 
								      + vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)
								      : vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1))) 
						    << 0x1f) 
						   | (QData)((IData)(
								     (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcA2) 
								       << 0x19) 
								      | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcB2) 
									  << 0x13) 
									 | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__Dst2) 
									     << 0xd) 
									    | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__Opcode2) 
										<< 5) 
									       | (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__MemFlg2) 
										<< 4) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__MulDivFlg2) 
										<< 3) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__BrJpFlg2) 
										<< 2) 
										| (((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__unConJpFlg2) 
										<< 1) 
										| (IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__AluFlg2))))))))))))) 
				     >> 0x20)) >> 0x1d));
	vcdp->chgArray(c+36,(__Vtemp2),99);
	vcdp->chgBus  (c+40,(((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__link1)
			       ? ((IData)(8) + vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in1)
			       : vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__signExtended_output1)),32);
	vcdp->chgBus  (c+41,(((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__link1)
			       ? ((IData)(8) + vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)
			       : vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1)),32);
	vcdp->chgBus  (c+44,(((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__jumpRegister_Flag1)
			       ? ((0xf0000000 & vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in1) 
				  | (0xffffffc & (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_decoder_in1 
						  << 2)))
			       : vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in1)),32);
	vcdp->chgBus  (c+45,(((IData)(4) + (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in1 
					    + (vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__signExtended_output1 
					       << 2)))),32);
	vcdp->chgBus  (c+42,(((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__jump1)
			       ? ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__jumpRegister_Flag1)
				   ? ((0xf0000000 & vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in1) 
				      | (0xffffffc 
					 & (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_decoder_in1 
					    << 2)))
				   : vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in1)
			       : ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__taken_branch1)
				   ? ((IData)(4) + 
				      (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in1 
				       + (vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__signExtended_output1 
					  << 2))) : 
				  ((IData)(4) + vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in1)))),32);
	vcdp->chgBus  (c+46,(((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__jumpRegister_Flag1)
			       ? ((0xf0000000 & vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2) 
				  | (0xffffffc & (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_decoder_in2 
						  << 2)))
			       : vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)),32);
	vcdp->chgBus  (c+47,(((IData)(4) + (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2 
					    + (vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1 
					       << 2)))),32);
	vcdp->chgBus  (c+43,(((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__jump1)
			       ? ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__jumpRegister_Flag1)
				   ? ((0xf0000000 & vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2) 
				      | (0xffffffc 
					 & (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_decoder_in2 
					    << 2)))
				   : vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)
			       : ((IData)(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__taken_branch1)
				   ? ((IData)(4) + 
				      (vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2 
				       + (vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1 
					  << 2))) : 
				  ((IData)(4) + vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_decoder_in2)))),32);
    }
}

void VMIPS::traceChgThis__6(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->chgBit  (c+49,(vlSymsp->TOP__v.__PVT__DMISS));
	vcdp->chgBit  (c+48,(vlSymsp->TOP__v.__PVT__rd_en2));
    }
}

void VMIPS::traceChgThis__7(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->chgBit  (c+50,(vlSymsp->TOP__v.__PVT__IMISS));
	vcdp->chgBit  (c+51,(vlSymsp->TOP__v.__PVT__iCache1__DOT__hit1));
	vcdp->chgBit  (c+52,(vlSymsp->TOP__v.__PVT__iCache1__DOT__hit2));
	vcdp->chgArray(c+53,(vlSymsp->TOP__v.__PVT__iCache1__DOT__cc0__DOT__block_out1),256);
	vcdp->chgArray(c+61,(vlSymsp->TOP__v.__PVT__iCache1__DOT__cc0__DOT__block_out2),256);
	vcdp->chgArray(c+69,(vlSymsp->TOP__v.__PVT__ID1__DOT__rq_data1),99);
	vcdp->chgBit  (c+73,(vlSymsp->TOP__v.__PVT__ID1__DOT__UseImm1));
	vcdp->chgBit  (c+74,(vlSymsp->TOP__v.__PVT__ID1__DOT__UseImm2));
	vcdp->chgBus  (c+75,(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcA1),6);
	vcdp->chgBus  (c+76,(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcA2),6);
	vcdp->chgBus  (c+77,(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcB1),6);
	vcdp->chgBus  (c+78,(vlSymsp->TOP__v.__PVT__ID1__DOT__SrcB2),6);
	vcdp->chgBus  (c+79,(vlSymsp->TOP__v.__PVT__ID1__DOT__Dst1),6);
	vcdp->chgBus  (c+80,(vlSymsp->TOP__v.__PVT__ID1__DOT__Dst2),6);
	vcdp->chgBus  (c+81,(vlSymsp->TOP__v.__PVT__ID1__DOT__Opcode1),8);
	vcdp->chgBus  (c+82,(vlSymsp->TOP__v.__PVT__ID1__DOT__Opcode2),8);
	vcdp->chgBit  (c+83,(vlSymsp->TOP__v.__PVT__ID1__DOT__MemFlg1));
	vcdp->chgBit  (c+84,(vlSymsp->TOP__v.__PVT__ID1__DOT__MemFlg2));
	vcdp->chgBit  (c+85,(vlSymsp->TOP__v.__PVT__ID1__DOT__MulDivFlg1));
	vcdp->chgBit  (c+86,(vlSymsp->TOP__v.__PVT__ID1__DOT__MulDivFlg2));
	vcdp->chgBit  (c+87,(vlSymsp->TOP__v.__PVT__ID1__DOT__BrJpFlg1));
	vcdp->chgBit  (c+88,(vlSymsp->TOP__v.__PVT__ID1__DOT__BrJpFlg2));
	vcdp->chgBit  (c+89,(vlSymsp->TOP__v.__PVT__ID1__DOT__SysCallFlg1));
	vcdp->chgBit  (c+90,(vlSymsp->TOP__v.__PVT__ID1__DOT__SysCallFlg2));
	vcdp->chgBus  (c+91,(vlSymsp->TOP__v.__PVT__ID1__DOT__queueSel1),2);
	vcdp->chgBus  (c+92,(vlSymsp->TOP__v.__PVT__ID1__DOT__queueSel2),2);
	vcdp->chgBit  (c+93,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__link1));
	vcdp->chgBit  (c+94,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__RegDst1));
	vcdp->chgBit  (c+95,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__jump1));
	vcdp->chgBit  (c+96,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__branch1));
	vcdp->chgBit  (c+97,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__MemRead1));
	vcdp->chgBit  (c+98,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__MemWrite1));
	vcdp->chgBit  (c+99,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__RegWrite1));
	vcdp->chgBit  (c+100,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__jumpRegister_Flag1));
	vcdp->chgBit  (c+101,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__sign_or_zero_Flag1));
	vcdp->chgBus  (c+102,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__ALU_control1),6);
	vcdp->chgBus  (c+103,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__signExtended_output1),32);
	vcdp->chgBus  (c+104,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__opcode1),6);
	vcdp->chgBus  (c+105,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__format1),5);
	vcdp->chgBus  (c+106,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__rt1),5);
	vcdp->chgBus  (c+107,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__funct1),6);
	vcdp->chgBit  (c+108,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder1__DOT__MemtoReg1));
	vcdp->chgBit  (c+109,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__link1));
	vcdp->chgBit  (c+110,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__RegDst1));
	vcdp->chgBit  (c+111,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__jump1));
	vcdp->chgBit  (c+112,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__branch1));
	vcdp->chgBit  (c+113,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__MemRead1));
	vcdp->chgBit  (c+114,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__MemWrite1));
	vcdp->chgBit  (c+115,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__RegWrite1));
	vcdp->chgBit  (c+116,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__jumpRegister_Flag1));
	vcdp->chgBit  (c+117,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__sign_or_zero_Flag1));
	vcdp->chgBus  (c+118,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__ALU_control1),6);
	vcdp->chgBus  (c+119,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__signExtended_output1),32);
	vcdp->chgBus  (c+120,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__opcode1),6);
	vcdp->chgBus  (c+121,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__format1),5);
	vcdp->chgBus  (c+122,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__rt1),5);
	vcdp->chgBus  (c+123,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__funct1),6);
	vcdp->chgBit  (c+124,(vlSymsp->TOP__v.__PVT__ID1__DOT__decoder2__DOT__MemtoReg1));
    }
}

void VMIPS::traceChgThis__8(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->chgBit  (c+125,((8 == (IData)(vlSymsp->TOP__v.__PVT__dCache1__DOT__waitCount))));
	vcdp->chgBit  (c+126,((8 == (IData)(vlSymsp->TOP__v.__PVT__iCache1__DOT__waitCount))));
	vcdp->chgArray(c+127,(vlSymsp->TOP__v.__PVT__rq_out2),99);
	vcdp->chgBus  (c+131,(vlSymsp->TOP__v.__PVT__BrJpFlg),2);
	vcdp->chgBus  (c+132,(vlSymsp->TOP__v.__PVT__n),32);
	vcdp->chgBit  (c+133,((9 == (IData)(vlSymsp->TOP__v.__PVT__iCache1__DOT__waitCount))));
	vcdp->chgBus  (c+134,(vlSymsp->TOP__v.__PVT__iCache1__DOT__waitCount),4);
	vcdp->chgBit  (c+135,(((~ (((0x1ff & (vlSymsp->TOP__v.data_address_2DM 
					      >> 5)) 
				    <= 0x100) & (vlSymsp->TOP__v.__PVT__dCache1__DOT__policy[
						 (0xf 
						  & (vlSymsp->TOP__v.data_address_2DM 
						     >> 0xa))] 
						 >> 
						 (0x1f 
						  & (vlSymsp->TOP__v.data_address_2DM 
						     >> 5))))) 
			       & (9 == (IData)(vlSymsp->TOP__v.__PVT__dCache1__DOT__waitCount)))));
	vcdp->chgBit  (c+136,(((((0x1ff & (vlSymsp->TOP__v.data_address_2DM 
					   >> 5)) <= 0x100) 
				& (vlSymsp->TOP__v.__PVT__dCache1__DOT__policy[
				   (0xf & (vlSymsp->TOP__v.data_address_2DM 
					   >> 0xa))] 
				   >> (0x1f & (vlSymsp->TOP__v.data_address_2DM 
					       >> 5)))) 
			       & (9 == (IData)(vlSymsp->TOP__v.__PVT__dCache1__DOT__waitCount)))));
	vcdp->chgBus  (c+137,(vlSymsp->TOP__v.__PVT__dCache1__DOT__waitCount),4);
	vcdp->chgBus  (c+138,(vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_droped),32);
	vcdp->chgBus  (c+139,(vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_addr_droped),32);
	vcdp->chgBit  (c+140,(vlSymsp->TOP__v.__PVT__ID1__DOT__Instr_droped_flg));
    }
}

void VMIPS::traceChgThis__9(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->chgBit  (c+141,(vlSymsp->TOP__v.__PVT__IF_stall));
	vcdp->chgBit  (c+144,((vlSymsp->TOP__v.__PVT__dec_q__DOT__remain_cnt 
			       < 2)));
	vcdp->chgBus  (c+154,(vlSymsp->TOP__v.__PVT__dec_q__DOT__remain_cnt),32);
	vcdp->chgBus  (c+155,(vlSymsp->TOP__v.__PVT__dec_q__DOT__wr_p),3);
	vcdp->chgBus  (c+156,(vlSymsp->TOP__v.__PVT__dec_q__DOT__rd_p),3);
	vcdp->chgQuad (c+157,(vlSymsp->TOP__v.__PVT__dec_q__DOT__ram[0]),64);
	vcdp->chgQuad (c+159,(vlSymsp->TOP__v.__PVT__dec_q__DOT__ram[1]),64);
	vcdp->chgQuad (c+161,(vlSymsp->TOP__v.__PVT__dec_q__DOT__ram[2]),64);
	vcdp->chgQuad (c+163,(vlSymsp->TOP__v.__PVT__dec_q__DOT__ram[3]),64);
	vcdp->chgQuad (c+165,(vlSymsp->TOP__v.__PVT__dec_q__DOT__ram[4]),64);
	vcdp->chgQuad (c+167,(vlSymsp->TOP__v.__PVT__dec_q__DOT__ram[5]),64);
	vcdp->chgQuad (c+169,(vlSymsp->TOP__v.__PVT__dec_q__DOT__ram[6]),64);
	vcdp->chgQuad (c+171,(vlSymsp->TOP__v.__PVT__dec_q__DOT__ram[7]),64);
	vcdp->chgBit  (c+145,((vlSymsp->TOP__v.__PVT__dec_q__DOT__remain_cnt 
			       > 6)));
	vcdp->chgBit  (c+142,(vlSymsp->TOP__v.__PVT__wr_en1));
	vcdp->chgBit  (c+143,(vlSymsp->TOP__v.__PVT__wr_en2));
	vcdp->chgQuad (c+146,(vlSymsp->TOP__v.__PVT__dq_in1),64);
	vcdp->chgQuad (c+148,(vlSymsp->TOP__v.__PVT__dq_in2),64);
	vcdp->chgBus  (c+173,(vlSymsp->TOP__v.__PVT__IF1__DOT__PC),32);
	vcdp->chgBus  (c+174,(((IData)(4) + vlSymsp->TOP__v.__PVT__IF1__DOT__PC)),32);
	vcdp->chgBus  (c+175,(vlSymsp->TOP__v.__PVT__IF1__DOT__FPC),32);
	vcdp->chgBus  (c+176,(((IData)(4) + vlSymsp->TOP__v.__PVT__IF1__DOT__FPC)),32);
	vcdp->chgQuad (c+150,(vlSymsp->TOP__v.__PVT__dq_out1),64);
	vcdp->chgQuad (c+152,(vlSymsp->TOP__v.__PVT__dq_out2),64);
    }
}

void VMIPS::traceChgThis__10(VMIPS__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VMIPS* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c=code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
	vcdp->chgBus  (c+177,(vlTOPp->R2_output),32);
	vcdp->chgBus  (c+178,(vlTOPp->data_address_2DM),32);
	vcdp->chgBus  (c+179,(vlTOPp->data_write_2DM),32);
	vcdp->chgArray(c+180,(vlTOPp->block_write_2DM),256);
	vcdp->chgArray(c+188,(vlTOPp->block_write1_2IM),256);
	vcdp->chgBit  (c+196,(vlTOPp->MemRead));
	vcdp->chgBit  (c+197,(vlTOPp->MemWrite));
	vcdp->chgBit  (c+198,(vlTOPp->dBlkRead));
	vcdp->chgBit  (c+199,(vlTOPp->dBlkWrite));
	vcdp->chgBit  (c+200,(vlTOPp->iBlkRead));
	vcdp->chgBit  (c+201,(vlTOPp->iBlkWrite));
	vcdp->chgBus  (c+203,(vlTOPp->R2_input),32);
	vcdp->chgBus  (c+204,(vlTOPp->data_read_fDM),32);
	vcdp->chgBus  (c+231,(vlSymsp->TOP__v.R2_output_ID),32);
	vcdp->chgBus  (c+232,(vlSymsp->TOP__v.Instr_fMEM),32);
	vcdp->chgBus  (c+233,(vlSymsp->TOP__v.Reg_ID[0]),32);
	vcdp->chgBus  (c+234,(vlSymsp->TOP__v.Reg_ID[1]),32);
	vcdp->chgBus  (c+235,(vlSymsp->TOP__v.Reg_ID[2]),32);
	vcdp->chgBus  (c+236,(vlSymsp->TOP__v.Reg_ID[3]),32);
	vcdp->chgBus  (c+237,(vlSymsp->TOP__v.Reg_ID[4]),32);
	vcdp->chgBus  (c+238,(vlSymsp->TOP__v.Reg_ID[5]),32);
	vcdp->chgBus  (c+239,(vlSymsp->TOP__v.Reg_ID[6]),32);
	vcdp->chgBus  (c+240,(vlSymsp->TOP__v.Reg_ID[7]),32);
	vcdp->chgBus  (c+241,(vlSymsp->TOP__v.Reg_ID[8]),32);
	vcdp->chgBus  (c+242,(vlSymsp->TOP__v.Reg_ID[9]),32);
	vcdp->chgBus  (c+243,(vlSymsp->TOP__v.Reg_ID[10]),32);
	vcdp->chgBus  (c+244,(vlSymsp->TOP__v.Reg_ID[11]),32);
	vcdp->chgBus  (c+245,(vlSymsp->TOP__v.Reg_ID[12]),32);
	vcdp->chgBus  (c+246,(vlSymsp->TOP__v.Reg_ID[13]),32);
	vcdp->chgBus  (c+247,(vlSymsp->TOP__v.Reg_ID[14]),32);
	vcdp->chgBus  (c+248,(vlSymsp->TOP__v.Reg_ID[15]),32);
	vcdp->chgBus  (c+249,(vlSymsp->TOP__v.Reg_ID[16]),32);
	vcdp->chgBus  (c+250,(vlSymsp->TOP__v.Reg_ID[17]),32);
	vcdp->chgBus  (c+251,(vlSymsp->TOP__v.Reg_ID[18]),32);
	vcdp->chgBus  (c+252,(vlSymsp->TOP__v.Reg_ID[19]),32);
	vcdp->chgBus  (c+253,(vlSymsp->TOP__v.Reg_ID[20]),32);
	vcdp->chgBus  (c+254,(vlSymsp->TOP__v.Reg_ID[21]),32);
	vcdp->chgBus  (c+255,(vlSymsp->TOP__v.Reg_ID[22]),32);
	vcdp->chgBus  (c+256,(vlSymsp->TOP__v.Reg_ID[23]),32);
	vcdp->chgBus  (c+257,(vlSymsp->TOP__v.Reg_ID[24]),32);
	vcdp->chgBus  (c+258,(vlSymsp->TOP__v.Reg_ID[25]),32);
	vcdp->chgBus  (c+259,(vlSymsp->TOP__v.Reg_ID[26]),32);
	vcdp->chgBus  (c+260,(vlSymsp->TOP__v.Reg_ID[27]),32);
	vcdp->chgBus  (c+261,(vlSymsp->TOP__v.Reg_ID[28]),32);
	vcdp->chgBus  (c+262,(vlSymsp->TOP__v.Reg_ID[29]),32);
	vcdp->chgBus  (c+263,(vlSymsp->TOP__v.Reg_ID[30]),32);
	vcdp->chgBus  (c+264,(vlSymsp->TOP__v.Reg_ID[31]),32);
	vcdp->chgBus  (c+267,(vlSymsp->TOP__v.CIA_IFID),32);
	vcdp->chgBus  (c+268,(vlSymsp->TOP__v.CIB_IFID),32);
	vcdp->chgBus  (c+269,(vlSymsp->TOP__v.PCA_IFID),32);
	vcdp->chgBus  (c+270,(vlSymsp->TOP__v.PCB_IFID),32);
	vcdp->chgBus  (c+271,(vlSymsp->TOP__v.nextInstruction_address1_IDIF),32);
	vcdp->chgBit  (c+272,(vlSymsp->TOP__v.no_fetch));
	vcdp->chgBus  (c+275,(vlSymsp->TOP__v.writeData1_WBID),32);
	vcdp->chgBus  (c+276,(vlSymsp->TOP__v.writeData2_WBID),32);
	vcdp->chgBus  (c+277,(vlSymsp->TOP__v.writeData1_WBEXE),32);
	vcdp->chgBus  (c+278,(vlSymsp->TOP__v.writeData2_WBEXE),32);
	vcdp->chgBus  (c+279,(vlSymsp->TOP__v.writeData1_MID),32);
	vcdp->chgBus  (c+280,(vlSymsp->TOP__v.writeData2_MID),32);
	vcdp->chgBus  (c+281,(vlSymsp->TOP__v.Dest_Value1_IDEXE),32);
	vcdp->chgBus  (c+282,(vlSymsp->TOP__v.Dest_Value2_IDEXE),32);
	vcdp->chgBus  (c+283,(vlSymsp->TOP__v.Dest_Value1_EXEM),32);
	vcdp->chgBus  (c+284,(vlSymsp->TOP__v.Dest_Value2_EXEM),32);
	vcdp->chgBus  (c+285,(vlSymsp->TOP__v.Instr1_IDEXE),32);
	vcdp->chgBus  (c+286,(vlSymsp->TOP__v.Instr2_IDEXE),32);
	vcdp->chgBus  (c+287,(vlSymsp->TOP__v.Instr1_EXEM),32);
	vcdp->chgBus  (c+288,(vlSymsp->TOP__v.Instr2_EXEM),32);
	vcdp->chgBus  (c+289,(vlSymsp->TOP__v.Instr1_IFID),32);
	vcdp->chgBus  (c+290,(vlSymsp->TOP__v.Instr2_IFID),32);
	vcdp->chgBus  (c+291,(vlSymsp->TOP__v.Operand_A1_IDEXE),32);
	vcdp->chgBus  (c+292,(vlSymsp->TOP__v.Operand_A2_IDEXE),32);
	vcdp->chgBus  (c+293,(vlSymsp->TOP__v.Operand_B1_IDEXE),32);
	vcdp->chgBus  (c+294,(vlSymsp->TOP__v.Operand_B2_IDEXE),32);
	vcdp->chgBus  (c+295,(vlSymsp->TOP__v.aluResult1_EXEM),32);
	vcdp->chgBus  (c+296,(vlSymsp->TOP__v.aluResult2_EXEM),32);
	vcdp->chgBus  (c+297,(vlSymsp->TOP__v.aluResult1_EXEID),32);
	vcdp->chgBus  (c+298,(vlSymsp->TOP__v.aluResult2_EXEID),32);
	vcdp->chgBus  (c+299,(vlSymsp->TOP__v.aluResult1_MEMW),32);
	vcdp->chgBus  (c+300,(vlSymsp->TOP__v.aluResult2_MEMW),32);
	vcdp->chgBus  (c+301,(vlSymsp->TOP__v.aluResult1_WBID),32);
	vcdp->chgBus  (c+302,(vlSymsp->TOP__v.aluResult2_WBID),32);
	vcdp->chgBus  (c+303,(vlSymsp->TOP__v.data_read1_MEMW),32);
	vcdp->chgBus  (c+304,(vlSymsp->TOP__v.data_read2_MEMW),32);
	vcdp->chgBus  (c+305,(vlSymsp->TOP__v.readDataB1_IDEXE),32);
	vcdp->chgBus  (c+306,(vlSymsp->TOP__v.readDataB2_IDEXE),32);
	vcdp->chgBus  (c+307,(vlSymsp->TOP__v.readDataB1_EXEM),32);
	vcdp->chgBus  (c+308,(vlSymsp->TOP__v.readDataB2_EXEM),32);
	vcdp->chgBus  (c+309,(vlSymsp->TOP__v.ALU_control1_IDEXE),6);
	vcdp->chgBus  (c+310,(vlSymsp->TOP__v.ALU_control2_IDEXE),6);
	vcdp->chgBus  (c+311,(vlSymsp->TOP__v.ALU_control1_EXEM),6);
	vcdp->chgBus  (c+312,(vlSymsp->TOP__v.ALU_control2_EXEM),6);
	vcdp->chgBus  (c+313,(vlSymsp->TOP__v.writeRegister1_IDEXE),5);
	vcdp->chgBus  (c+314,(vlSymsp->TOP__v.writeRegister2_IDEXE),5);
	vcdp->chgBus  (c+315,(vlSymsp->TOP__v.writeRegister1_EXEM),5);
	vcdp->chgBus  (c+316,(vlSymsp->TOP__v.writeRegister2_EXEM),5);
	vcdp->chgBus  (c+317,(vlSymsp->TOP__v.writeRegister1_MEMW),5);
	vcdp->chgBus  (c+318,(vlSymsp->TOP__v.writeRegister2_MEMW),5);
	vcdp->chgBus  (c+319,(vlSymsp->TOP__v.writeRegister1_WBID),5);
	vcdp->chgBus  (c+320,(vlSymsp->TOP__v.writeRegister2_WBID),5);
	vcdp->chgBus  (c+321,(vlSymsp->TOP__v.writeRegister1_WBEXE),5);
	vcdp->chgBus  (c+322,(vlSymsp->TOP__v.writeRegister2_WBEXE),5);
	vcdp->chgBus  (c+323,(vlSymsp->TOP__v.Instr1_10_6_IDEXE),5);
	vcdp->chgBus  (c+324,(vlSymsp->TOP__v.Instr2_10_6_IDEXE),5);
	vcdp->chgBus  (c+325,(vlSymsp->TOP__v.readRegisterA2_IDEXE),5);
	vcdp->chgBus  (c+326,(vlSymsp->TOP__v.readRegisterA1_IDEXE),5);
	vcdp->chgBus  (c+327,(vlSymsp->TOP__v.readRegisterB1_IDEXE),5);
	vcdp->chgBus  (c+328,(vlSymsp->TOP__v.readRegisterB2_IDEXE),5);
	vcdp->chgBit  (c+329,(vlSymsp->TOP__v.MemtoReg1_IDEXE));
	vcdp->chgBit  (c+330,(vlSymsp->TOP__v.MemtoReg2_IDEXE));
	vcdp->chgBit  (c+331,(vlSymsp->TOP__v.MemtoReg1_EXEM));
	vcdp->chgBit  (c+332,(vlSymsp->TOP__v.MemtoReg2_EXEM));
	vcdp->chgBit  (c+333,(vlSymsp->TOP__v.MemtoReg1_MEMW));
	vcdp->chgBit  (c+334,(vlSymsp->TOP__v.MemtoReg2_MEMW));
	vcdp->chgBit  (c+335,(vlSymsp->TOP__v.MemRead1_IDEXE));
	vcdp->chgBit  (c+336,(vlSymsp->TOP__v.MemRead2_IDEXE));
	vcdp->chgBit  (c+337,(vlSymsp->TOP__v.MemRead1_EXEM));
	vcdp->chgBit  (c+338,(vlSymsp->TOP__v.MemRead2_EXEM));
	vcdp->chgBit  (c+339,(vlSymsp->TOP__v.MemWrite1_IDEXE));
	vcdp->chgBit  (c+340,(vlSymsp->TOP__v.MemWrite2_IDEXE));
	vcdp->chgBit  (c+341,(vlSymsp->TOP__v.MemWrite1_EXEM));
	vcdp->chgBit  (c+342,(vlSymsp->TOP__v.MemWrite2_EXEM));
	vcdp->chgBit  (c+343,(vlSymsp->TOP__v.do_writeback1_WBID));
	vcdp->chgBit  (c+344,(vlSymsp->TOP__v.do_writeback2_WBID));
	vcdp->chgBit  (c+345,(vlSymsp->TOP__v.do_writeback1_IDEXE));
	vcdp->chgBit  (c+346,(vlSymsp->TOP__v.do_writeback2_IDEXE));
	vcdp->chgBit  (c+347,(vlSymsp->TOP__v.do_writeback1_MEMW));
	vcdp->chgBit  (c+348,(vlSymsp->TOP__v.do_writeback2_MEMW));
	vcdp->chgBit  (c+349,(vlSymsp->TOP__v.do_writeback1_EXEM));
	vcdp->chgBit  (c+350,(vlSymsp->TOP__v.do_writeback2_EXEM));
	vcdp->chgBit  (c+351,(vlSymsp->TOP__v.do_writeback1_WBEXE));
	vcdp->chgBit  (c+352,(vlSymsp->TOP__v.do_writeback2_WBEXE));
	vcdp->chgBit  (c+353,(vlSymsp->TOP__v.taken_branch1_IDIF));
	vcdp->chgBit  (c+354,(vlSymsp->TOP__v.taken_branch2_IDIF));
	vcdp->chgBit  (c+355,(vlSymsp->TOP__v.fetchNull1_fID));
	vcdp->chgBit  (c+356,(vlSymsp->TOP__v.fetchNull2_fID));
	vcdp->chgBit  (c+357,(vlSymsp->TOP__v.ALUSrc1_IDEXE));
	vcdp->chgBit  (c+358,(vlSymsp->TOP__v.ALUSrc2_IDEXE));
	vcdp->chgBit  (c+359,(vlSymsp->TOP__v.ALUSrc1_EXEM));
	vcdp->chgBit  (c+360,(vlSymsp->TOP__v.ALUSrc2_EXEM));
	vcdp->chgBit  (c+361,(vlSymsp->TOP__v.FREEZE));
	vcdp->chgArray(c+362,(vlSymsp->TOP__v.rq_out1),99);
	vcdp->chgBus  (c+368,(vlSymsp->TOP__v.MVECT),2);
	vcdp->chgBit  (c+369,((1 & (~ (IData)(vlSymsp->TOP__v.no_fetch)))));
	vcdp->chgArray(c+213,(vlTOPp->block_read1_fIM),256);
	vcdp->chgArray(c+221,(vlTOPp->block_read2_fIM),256);
	vcdp->chgBus  (c+370,((0x1f & vlSymsp->TOP__v.Instr_address1_2IM)),5);
	vcdp->chgBus  (c+371,((0x3ff & (vlSymsp->TOP__v.Instr_address1_2IM 
					>> 5))),10);
	vcdp->chgBus  (c+372,((0x1ffff & (vlSymsp->TOP__v.Instr_address1_2IM 
					  >> 0xf))),17);
	vcdp->chgBus  (c+373,((0x1f & vlSymsp->TOP__v.Instr_address2_2IM)),5);
	vcdp->chgBus  (c+374,((0x3ff & (vlSymsp->TOP__v.Instr_address2_2IM 
					>> 5))),10);
	vcdp->chgBus  (c+375,((0x1ffff & (vlSymsp->TOP__v.Instr_address2_2IM 
					  >> 0xf))),17);
	vcdp->chgBit  (c+273,(vlSymsp->TOP__v.SYS));
	vcdp->chgArray(c+205,(vlTOPp->block_read_fDM),256);
	vcdp->chgBus  (c+265,(vlSymsp->TOP__v.Instr_address1_2IM),32);
	vcdp->chgBus  (c+266,(vlSymsp->TOP__v.Instr_address2_2IM),32);
	vcdp->chgBus  (c+366,(vlSymsp->TOP__v.Instr1_fIC),32);
	vcdp->chgBus  (c+367,(vlSymsp->TOP__v.Instr2_fIC),32);
	vcdp->chgBit  (c+274,(vlSymsp->TOP__v.single_fetch_IDIF));
	vcdp->chgBus  (c+202,(vlTOPp->PC_init),32);
	vcdp->chgBus  (c+376,(((IData)(vlSymsp->TOP__v.fetchNull1_fID)
			        ? 0 : vlSymsp->TOP__v.Instr1_fIC)),32);
	vcdp->chgBus  (c+377,(((IData)(vlSymsp->TOP__v.fetchNull2_fID)
			        ? 0 : vlSymsp->TOP__v.Instr2_fIC)),32);
	vcdp->chgBit  (c+229,(vlTOPp->CLK));
	vcdp->chgBit  (c+230,(vlTOPp->RESET));
    }
}
